#!/usr/bin/env python3
"""Build docs/04-estimate.xlsx (formula-driven) and fill effort columns in data/module-catalog.csv.

Run from the repository root:  python3 tools/build_estimate.py
"""
import csv, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from estimate_model import *
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.table import Table

F = "Arial"
blue = Font(name=F, size=10, color="0000FF")
blk = Font(name=F, size=10)
bold = Font(name=F, size=10, bold=True)
hdr = Font(name=F, size=10, bold=True, color="FFFFFF")
hfill = PatternFill("solid", fgColor="23395B")
yfill = PatternFill("solid", fgColor="FFFF99")
gfill = PatternFill("solid", fgColor="EEF1EC")
thin = Side(style="thin", color="C8D0C9")
H0 = '#,##0;(#,##0);-'
USD = '$#,##0;($#,##0);-'

wb = Workbook()
# ---------------- Inputs ----------------
wi = wb.active; wi.title = "Inputs"
wi["A1"] = "Inputs and assumptions"; wi["A1"].font = Font(name=F, size=14, bold=True)
wi["A2"] = "Blue cells are inputs. Change them and every sheet recalculates."; wi["A2"].font = blk
rows = [("Rate (USD per man-hour)", EF["rate_usd"], USD, "Agreed with Ali, 3 Nov 2026"),
        ("Team size (developers)", EF["team"], "0", "One front-end, one back-end"),
        ("Billable hours per person per week", EF["capacity_h_per_week_per_person"], "0", "40 h week less meetings and leave; used only for the schedule"),
        ("Overhead: testing, automation, acceptance fixes", EF["overheads"]["qa"], "0%", "Share of development and adapter hours"),
        ("Overhead: project management and coordination", EF["overheads"]["pm"], "0%", ""),
        ("Overhead: documentation, training, handover", EF["overheads"]["docs"], "0%", ""),
        ("Overhead: security review and fixes", EF["overheads"]["security"], "0%", "External penetration test is not included"),
        ("Contingency (on likely hours)", EF["contingency"], "0%", "Shown separately; part of the proposed budget, not of the likely effort"),
        ("Mockup revision hours after client review", EF["mockup"]["revision_hours"], "0", "Changes to existing screens"),
        ("Additional pages allowed after review (max)", EF["mockup"]["new_pages_max"], "0", "Agreed with Ali, 3 Nov 2026"),
        ("Mockup hours per additional page", EF["mockup"]["per_new_page_mockup_h"], "0", ""),
        ("Build hours per additional page, front-end", EF["mockup"]["per_new_page_build"]["fe"], "0", "Average page: list or form with its logic"),
        ("Build hours per additional page, back-end", EF["mockup"]["per_new_page_build"]["be"], "0", "")]
wi["A4"], wi["B4"], wi["C4"] = "Item", "Value", "Note"
for c in ("A4", "B4", "C4"): wi[c].font = hdr; wi[c].fill = hfill
for i, (a, v, fmt, n) in enumerate(rows):
    r = 5 + i
    wi.cell(r, 1, a).font = blk; c = wi.cell(r, 2, v); c.font = blue; c.number_format = fmt; wi.cell(r, 3, n).font = blk
RATE, TEAM, CAP, OHQ, OHP, OHD, OHS, CONT, MREV, MNEW, MPG, MFE, MBE = ["Inputs!$B$%d" % (5 + i) for i in range(13)]
wi["A19"] = "Uncertainty classes"; wi["A19"].font = bold
for j, h in enumerate(["Class", "Low factor", "High factor", "Meaning"]):
    c = wi.cell(20, 1 + j, h); c.font = hdr; c.fill = hfill
for k, (cl, d) in enumerate(CL.items()):
    r = 21 + k
    wi.cell(r, 1, cl).font = bold
    c = wi.cell(r, 2, d["low"]); c.font = blue; c.number_format = "0.00"
    c = wi.cell(r, 3, d["high"]); c.font = blue; c.number_format = "0.00"
    wi.cell(r, 4, d["label"]).font = blk
wi["A25"] = "Low and high hours are the likely hours times these factors. Adapter hours are entered as explicit low, likely and high values."; wi["A25"].font = blk
wi.column_dimensions["A"].width = 52; wi.column_dimensions["B"].width = 12; wi.column_dimensions["C"].width = 70; wi.column_dimensions["D"].width = 70
CLS_N, CLS_L, CLS_H = "Inputs!$A$21:$A$23", "Inputs!$B$21:$B$23", "Inputs!$C$21:$C$23"

# ---------------- Items ----------------
ws = wb.create_sheet("Items")
heads = ["ID", "Line", "Part", "Tier", "Area", "Class", "Front h", "Back h", "Likely h", "Low h", "High h", "Adapter low h", "Adapter likely h", "Adapter high h",
         "Core", "Recommended", "Extended", "Full", "Custom"]
ws["A1"] = "Priced lines. Package columns (O to S) are 1 = included, 0 = not. Edit the Custom column to price any combination (dependencies are not checked here)."
ws["A1"].font = bold
for j, h in enumerate(heads):
    c = ws.cell(3, 1 + j, h); c.font = hdr; c.fill = hfill; c.alignment = Alignment(wrap_text=True, vertical="center")
its = items()
area = {"A1": "A1 Platform", "A2": "A2 Finance", "A3": "A3 HR"}
r = 4
first = r
for i in its:
    pk = {p: (1 if (i["part"] == "A" or i["id"] in package_ids(p)) else 0) for p in PACKAGES}
    ad = i["adapter"] or [None, None, None]
    vals = [i["id"], i["name"], i["part"], i["tier"], area.get(i["group"], i["id"] + " " + i["name"] if i["part"] != "A" else i["group"]), i["cls"], i["fe"], i["be"]]
    for j, v in enumerate(vals):
        c = ws.cell(r, 1 + j, v); c.font = blue if j in (5, 6, 7) else blk
    ws.cell(r, 9, f"=G{r}+H{r}").font = blk
    ws.cell(r, 10, f"=I{r}*INDEX({CLS_L},MATCH(F{r},{CLS_N},0))").font = blk
    ws.cell(r, 11, f"=I{r}*INDEX({CLS_H},MATCH(F{r},{CLS_N},0))").font = blk
    for j, v in enumerate(ad):
        c = ws.cell(r, 12 + j, v); c.font = blue
    for j, p in enumerate(PACKAGES):
        ws.cell(r, 15 + j, pk[p]).font = blue
    ws.cell(r, 19, pk["Recommended"]).font = blue
    r += 1
# allowance lines (formulas from Inputs)
for name, fe, be, cls in (("Mockup revision after client review, including additional pages", f"={MREV}+{MNEW}*{MPG}", 0, "S"),
                          ("Build of the additional pages after review", f"={MNEW}*{MFE}", f"={MNEW}*{MBE}", "M")):
    ws.cell(r, 1, "X.%02d" % (r - first - len(its) + 1)).font = blk
    ws.cell(r, 2, name).font = blk; ws.cell(r, 3, "Allowance").font = blk; ws.cell(r, 4, "-").font = blk; ws.cell(r, 5, "Allowance for review changes").font = blk
    ws.cell(r, 6, cls).font = blue
    ws.cell(r, 7, fe).font = blk; ws.cell(r, 8, be).font = blk
    ws.cell(r, 9, f"=G{r}+H{r}").font = blk
    ws.cell(r, 10, f"=I{r}*INDEX({CLS_L},MATCH(F{r},{CLS_N},0))").font = blk
    ws.cell(r, 11, f"=I{r}*INDEX({CLS_H},MATCH(F{r},{CLS_N},0))").font = blk
    for j in range(5): ws.cell(r, 15 + j, 1).font = blue
    r += 1
last = r - 1
for row in ws.iter_rows(min_row=first, max_row=last, min_col=7, max_col=14):
    for c in row: c.number_format = H0
ws.freeze_panes = "C4"
for col, w in zip("ABCDEFGHIJKLMNOPQRS", [8, 70, 10, 8, 30, 7, 8, 8, 9, 9, 9, 9, 9, 9, 7, 13, 9, 7, 8]):
    ws.column_dimensions[col].width = w
ws.row_dimensions[3].height = 30
rg = lambda col: f"Items!${col}${first}:${col}${last}"

# ---------------- Packages ----------------
wp = wb.create_sheet("Packages")
wp["A1"] = "Package calculation"; wp["A1"].font = Font(name=F, size=14, bold=True)
wp["A3"] = "Hours and USD"; wp["A3"].font = bold
pk_cols = {"Core": "O", "Recommended": "P", "Extended": "Q", "Full": "R", "Custom": "S"}
for j, p in enumerate(list(pk_cols)):
    c = wp.cell(3, 2 + j, p); c.font = hdr; c.fill = hfill; c.alignment = Alignment(horizontal="center")
wp["A3"].font = hdr; wp["A3"].fill = hfill
lab = ["Optional modules included (B and C)",
       "Development hours: low", "Development hours: likely", "Development hours: high",
       "Adapter hours: low", "Adapter hours: likely", "Adapter hours: high",
       "Overheads: low", "Overheads: likely", "Overheads: high",
       "TOTAL hours: low", "TOTAL hours: likely", "TOTAL hours: high",
       "Contingency hours (on likely)", "BUDGET hours (likely + contingency)",
       "USD: low", "USD: likely", "USD: high", "USD: BUDGET (likely + contingency)",
       "Weeks, 2 people: low", "Weeks, 2 people: likely", "Weeks, 2 people: high", "Weeks, 2 people: budget",
       "Front-end development hours (likely)", "Back-end development hours (likely)",
       "Overhead: testing and automation (likely)", "Overhead: project management (likely)", "Overhead: documentation and handover (likely)", "Overhead: security (likely)"]
for i, t in enumerate(lab):
    wp.cell(4 + i, 1, t).font = bold if t.isupper() or t.startswith(("TOTAL", "BUDGET", "USD: BUDGET")) else blk
OHS_ALL = f"({OHQ}+{OHP}+{OHD}+{OHS})"
for j, p in enumerate(pk_cols):
    col = L(2 + j); fl = rg(pk_cols[p])
    f = {}
    f[4] = f'=SUMPRODUCT({fl}*(({rg("C")}="B")+({rg("C")}="C")))'
    for k, c in enumerate("JIK"):   # low, likely, high -> columns J, I, K
        pass
    f[5] = f"=SUMPRODUCT({fl},{rg('J')})"; f[6] = f"=SUMPRODUCT({fl},{rg('I')})"; f[7] = f"=SUMPRODUCT({fl},{rg('K')})"
    f[8] = f"=SUMPRODUCT({fl},{rg('L')})"; f[9] = f"=SUMPRODUCT({fl},{rg('M')})"; f[10] = f"=SUMPRODUCT({fl},{rg('N')})"
    f[11] = f"=({col}5+{col}8)*{OHS_ALL}"; f[12] = f"=({col}6+{col}9)*{OHS_ALL}"; f[13] = f"=({col}7+{col}10)*{OHS_ALL}"
    f[14] = f"={col}5+{col}8+{col}11"; f[15] = f"={col}6+{col}9+{col}12"; f[16] = f"={col}7+{col}10+{col}13"
    f[17] = f"={col}15*{CONT}"; f[18] = f"={col}15+{col}17"
    f[19] = f"={col}14*{RATE}"; f[20] = f"={col}15*{RATE}"; f[21] = f"={col}16*{RATE}"; f[22] = f"={col}18*{RATE}"
    f[23] = f"={col}14/({CAP}*{TEAM})"; f[24] = f"={col}15/({CAP}*{TEAM})"; f[25] = f"={col}16/({CAP}*{TEAM})"; f[26] = f"={col}18/({CAP}*{TEAM})"
    f[27] = f"=SUMPRODUCT({fl},{rg('G')})"; f[28] = f"=SUMPRODUCT({fl},{rg('H')})"
    f[29] = f"=({col}6+{col}9)*{OHQ}"; f[30] = f"=({col}6+{col}9)*{OHP}"; f[31] = f"=({col}6+{col}9)*{OHD}"; f[32] = f"=({col}6+{col}9)*{OHS}"
    for rr, v in f.items():
        c = wp.cell(rr, 2 + j, v); c.font = bold if rr in (15, 18, 20, 22) else blk
        c.number_format = USD if 19 <= rr <= 22 else ("0.0" if 23 <= rr <= 26 else H0)
wp.column_dimensions["A"].width = 46
for j in range(5): wp.column_dimensions[L(2 + j)].width = 15
wp.freeze_panes = "B4"
# rows in `lab` start at 4; but formulas above use row numbers 4..32 mapped to label index+4 -> verify mapping
# lab index: 0->row4 modules; 1..3 dev low/likely/high -> rows 5,6,7; 4..6 adapters rows 8,9,10; 7..9 overheads rows 11,12,13; 10..12 totals rows 14,15,16;
# 13 contingency row 17; 14 budget row 18; 15..18 USD rows 19..22; 19..22 weeks rows 23..26; 23,24 FE/BE rows 27,28; 25..28 overhead split rows 29..32

# ---------------- Summary ----------------
wsum = wb.create_sheet("Summary", 0)
wsum["A1"] = "Astex HR and Finance Platform: estimate summary"; wsum["A1"].font = Font(name=F, size=14, bold=True)
wsum["A2"] = "USD at the rate on the Inputs sheet. Low and high are the range of effort; the budget is likely effort plus contingency. All containers, AI account and hardware are provided by Astex."; wsum["A2"].font = blk
heads = ["Package", "Optional modules", "USD low", "USD likely", "USD high", "USD budget (likely + contingency)", "Hours likely", "Weeks likely", "Weeks budget"]
for j, h in enumerate(heads):
    c = wsum.cell(4, 1 + j, h); c.font = hdr; c.fill = hfill; c.alignment = Alignment(wrap_text=True, vertical="center")
for i, p in enumerate(pk_cols):
    r = 5 + i; col = L(2 + i)
    wsum.cell(r, 1, p).font = bold
    for j, (src, fmt) in enumerate([(4, "0"), (19, USD), (20, USD), (21, USD), (22, USD), (15, H0), (24, "0.0"), (26, "0.0")]):
        c = wsum.cell(r, 2 + j, f"=Packages!{col}{src}"); c.font = blk; c.number_format = fmt
wsum["A11"] = "Core is the three Part A modules only. Recommended adds the 15 first-wave modules (tier R1), Extended adds the 12 second-wave modules (R2), Full adds the 11 optional modules. Custom follows the Custom column on the Items sheet."
wsum["A12"] = "Adapter lines (bank formats, NAV, EKAER, accounting export and so on) are ranges because the formats are not yet known. They narrow as Astex supplies samples and access."
wsum["A13"] = "The allowance for up to 10 additional pages after client review is included in every package."
for a in ("A11", "A12", "A13"): wsum[a].font = blk
wsum.column_dimensions["A"].width = 16
for j in range(2, 10): wsum.column_dimensions[L(j)].width = 16
wsum.row_dimensions[4].height = 44
wb.save(ROOT / "docs/04-estimate.xlsx")

# ------------- fill effort columns in module-catalog.csv -------------
src = ROOT / "data/module-catalog.csv"
rows = list(csv.reader(open(src, encoding="utf-8")))
head = rows[0]
ix = {n: head.index(n) for n in ("effort_low_h", "effort_likely_h", "effort_high_h")}
head += ["adapter_low_h", "adapter_likely_h", "adapter_high_h"]
byid = {}
for i in its:
    byid.setdefault(i["group"] if i["part"] == "A" else i["id"], []).append(i)
for r in rows[1:]:
    mid = r[0]; lst = byid.get(mid, [])
    r[ix["effort_low_h"]] = round(sum(x["low"] for x in lst)); r[ix["effort_likely_h"]] = round(sum(x["likely"] for x in lst)); r[ix["effort_high_h"]] = round(sum(x["high"] for x in lst))
    ad = lst[0]["adapter"] if lst and lst[0]["adapter"] else ["", "", ""]
    r += ad
with open(src, "w", newline="", encoding="utf-8") as f:
    csv.writer(f).writerows(rows)
print("built docs/04-estimate.xlsx and filled data/module-catalog.csv")
