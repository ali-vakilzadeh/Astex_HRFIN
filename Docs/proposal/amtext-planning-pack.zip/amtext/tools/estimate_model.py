"""Shared estimate model. Reads data/effort.json and data/modules.json; no side effects."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
EF = json.loads((ROOT / "data/effort.json").read_text(encoding="utf-8"))
MODS = json.loads((ROOT / "data/modules.json").read_text(encoding="utf-8"))["modules"]
BY = {m["id"]: m for m in MODS}
CL = EF["classes"]

def rng(fe, be, cls):
    base = fe + be
    return {"fe": fe, "be": be, "low": base * CL[cls]["low"], "likely": base, "high": base * CL[cls]["high"], "cls": cls}

def items():
    """Every priced line: dict(id, name, group, part, tier, fe, be, low, likely, high, cls, adapter(low,likely,high) or None)."""
    out = []
    names = {"A1": "Platform foundation", "A2": "Finance core", "A3": "HR core"}
    tpl = (ROOT / "docs/src/01-backlog.template.md").read_text(encoding="utf-8")
    import re
    title = {}
    for mm in re.finditer(r"^\| (A[123]\.\d\d) \| (.+?) \|", tpl, re.M):
        title[mm.group(1)] = mm.group(2)
    for sid, (fe, be, c) in EF["A_stories"].items():
        r = rng(fe, be, c); g = sid.split(".")[0]
        out.append(dict(id=sid, name=title.get(sid, sid), group=g, part="A", tier="core", adapter=None, **r))
    for fid, name, fe, be, c in EF["A_fixed"]:
        r = rng(fe, be, c)
        out.append(dict(id=fid, name=name, group="A1", part="A", tier="core", adapter=None, **r))
    for mid, (fe, be, c, ad) in EF["modules"].items():
        r = rng(fe, be, c)
        out.append(dict(id=mid, name=BY[mid]["name"], group=mid, part=BY[mid]["part"], tier=BY[mid]["tier"], adapter=ad, **r))
    return out

def allowance():
    mk = EF["mockup"]
    a = rng(mk["revision_hours"] + mk["new_pages_max"] * mk["per_new_page_mockup_h"], 0, "S")
    a["name"] = "Mockup revision after client review, including up to 10 additional pages"
    p = mk["per_new_page_build"]
    b = rng(p["fe"] * mk["new_pages_max"], p["be"] * mk["new_pages_max"], p["class"])
    b["name"] = "Build of up to 10 additional pages (average page: %d h front, %d h back)" % (p["fe"], p["be"])
    return a, b

PACKAGES = ["Core", "Recommended", "Extended", "Full"]
def package_ids(name):
    A = [m["id"] for m in MODS if m["part"] == "A"]
    t = lambda tier: [m["id"] for m in MODS if m["part"] != "A" and m["tier"] == tier]
    return {"Core": A, "Recommended": A + t("R1"), "Extended": A + t("R1") + t("R2"), "Full": [m["id"] for m in MODS]}[name]

def module_of(item):
    return item["group"] if item["part"] != "A" else item["group"]

def totals(pkg):
    ids = set(package_ids(pkg))
    its = [i for i in items() if (i["part"] == "A" or i["id"] in ids)]
    a, b = allowance()
    dev = {k: sum(i[k] for i in its) + a[k] + b[k] for k in ("low", "likely", "high")}
    fe = sum(i["fe"] for i in its) + a["fe"] + b["fe"]
    be = sum(i["be"] for i in its) + a["be"] + b["be"]
    ad = {"low": 0, "likely": 0, "high": 0}
    for i in its:
        if i["adapter"]:
            for k, v in zip(("low", "likely", "high"), i["adapter"]):
                ad[k] += v
    base = {k: dev[k] + ad[k] for k in dev}
    oh_pct = sum(EF["overheads"].values())
    oh = {k: base[k] * oh_pct for k in base}
    sub = {k: base[k] + oh[k] for k in base}
    cont = sub["likely"] * EF["contingency"]
    rate = EF["rate_usd"]
    cap = EF["capacity_h_per_week_per_person"] * EF["team"]
    return dict(pkg=pkg, n_mod=len(ids), dev=dev, ad=ad, oh=oh, sub=sub, cont=cont, fe=fe, be=be,
                total_h={"low": sub["low"], "likely": sub["likely"], "high": sub["high"], "budget": sub["likely"] + cont},
                usd={"low": sub["low"] * rate, "likely": sub["likely"] * rate, "high": sub["high"] * rate, "budget": (sub["likely"] + cont) * rate},
                weeks={k: v / cap for k, v in {"low": sub["low"], "likely": sub["likely"], "high": sub["high"], "budget": sub["likely"] + cont}.items()})

if __name__ == "__main__":
    for p in PACKAGES:
        t = totals(p)
        print(p, t["n_mod"], "dev", {k: round(v) for k, v in t["dev"].items()}, "adapters", {k: round(v) for k, v in t["ad"].items()},
              "oh", round(t["oh"]["likely"]), "cont", round(t["cont"]), "| hours", {k: round(v) for k, v in t["total_h"].items()},
              "| USD", {k: round(v) for k, v in t["usd"].items()}, "| weeks", {k: round(v, 1) for k, v in t["weeks"].items()}, "| FE/BE", round(t["fe"]), round(t["be"]))
    a, b = allowance(); print("allowance", round(a["likely"]), round(b["likely"]), round(b["low"]), round(b["high"]))
    A = [i for i in items() if i["part"] == "A"]
    for g in ("A1", "A2", "A3"):
        s = [i for i in A if i["group"] == g]; print(g, round(sum(i["likely"] for i in s)), round(sum(i["low"] for i in s)), round(sum(i["high"] for i in s)))
