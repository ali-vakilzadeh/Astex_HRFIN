#!/usr/bin/env python3
"""Build docs/01-backlog.md and docs/03-screen-list.md from data/modules.json and data/screens.json.

Run from the repository root:  python3 tools/build_docs.py
"""
import json, csv, sys
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parent.parent
mods_data = json.loads((ROOT / "data/modules.json").read_text(encoding="utf-8"))
scr_data = json.loads((ROOT / "data/screens.json").read_text(encoding="utf-8"))
MODS = mods_data["modules"]
SCREENS = scr_data["screens"]
ROLES = scr_data["roles"]
BY_ID = {m["id"]: m for m in MODS}

TIER_LABEL = {"core": "core", "R1": "R1 recommended", "R2": "R2 recommended later", "O": "O optional"}
PART_LABEL = {"A": "Core", "B": "Conditional", "C": "Suggested"}


def screens_of(mid):
    return [s for s in SCREENS if s["m"] == mid]


def join(items, none="none"):
    return ", ".join(items) if items else none


def md_table(header, rows):
    out = ["| " + " | ".join(header) + " |", "| " + " | ".join("---" for _ in header) + " |"]
    for r in rows:
        out.append("| " + " | ".join(str(c).replace("|", "\\|") for c in r) + " |")
    return "\n".join(out)


def overview(part):
    rows = []
    for m in MODS:
        if m["part"] != part:
            continue
        rows.append([m["id"], m["name"], m["group"], TIER_LABEL[m["tier"]], join(m["requires"], "-"), join(m["refs"], "-")])
    return md_table(["ID", "Module", "Area", "Tier", "Requires", "Plan refs"], rows)


def cards(part):
    out = []
    for m in MODS:
        if m["part"] != part:
            continue
        sc = screens_of(m["id"])
        ui = join([f"{s['id']} {s['t']}" for s in sc], "")
        if not ui:
            ui = "Panel inside S-A19 Supplier detail" if m["id"] == "C13" else "none"
        lines = [
            f"### {m['id']}. {m['name']}",
            "",
            f"{m['summary']}",
            "",
            f"- **Tier:** {TIER_LABEL[m['tier']]}. **Area:** {m['group']}. **Plan refs:** {join(m['refs'], '-')}",
            f"- **Requires:** {join(m['requires'], 'nothing beyond the core')}. **Uses if present:** {join(m['optional'])}",
            f"- **Client must supply:** " + "; ".join(m["needs"]),
            f"- **Events in:** {join(m['in'])}. **Events out:** {join(m['out'])}",
            f"- **Permissions:** {join(['`' + p + '`' for p in m['perms']])}",
            f"- **Settings:** {join(m['config'])}. **Secrets:** {join(m['secrets'])}",
            f"- **Adapter contract:** {m['adapter'] + ' (section 9)' if m['adapter'] else 'none'}",
            f"- **UI slots:** {ui}",
            f"- **Test samples:** " + "; ".join(m["tests"]),
            f"- **Effort:** to be estimated in task 2" + (" (framework and adapter separately)" if m["adapter"] else ""),
            "",
        ]
        out.append("\n".join(lines))
    return "\n".join(out)


def deps():
    rows = []
    for m in MODS:
        if m["part"] == "A":
            continue
        dependents = [x["id"] for x in MODS if m["id"] in x["requires"]]
        rows.append([m["id"], m["name"], join(m["requires"], "-"), join(m["optional"], "-"), join(dependents, "-")])
    return md_table(["Module", "Name", "Requires", "Uses if present", "Required by"], rows)


def closure(selected):
    sel = set(selected)
    ok = True
    for mid in list(sel):
        for r in BY_ID[mid]["requires"]:
            if r not in sel:
                print(f"WARNING: {mid} requires {r} which is not in the package", file=sys.stderr)
                ok = False
    return ok


def bundles():
    core = [m["id"] for m in MODS if m["part"] == "A"]
    rec = core + [m["id"] for m in MODS if m["part"] != "A" and m["tier"] == "R1"]
    ext = rec + [m["id"] for m in MODS if m["tier"] == "R2"]
    full = [m["id"] for m in MODS]
    for name, b in (("Core", core), ("Recommended", rec), ("Extended", ext), ("Full", full)):
        closure(b)
    def names(ids, base):
        extra = [i for i in ids if i not in base]
        return join(extra, "-")
    rows = [
        ["**Core**", "Part A only. Manual upload, OCR, review, translation, register, cases, matching, manual payment status; HR onboarding and expiry control", join(core)],
        ["**Recommended**", "Core plus everything we expect Astex to need at go-live: email intake, NAV, EKÁER, bank file, approvals, coding, rates, payment batches, statement reconciliation, accounting export, employment history, offboarding", names(rec, core)],
        ["**Extended**", "Recommended plus the second wave: NAV cross-check, period lock and reports, report builder, VAT checks, HR records, renewals, templates, payroll export, workforce reports, multi-entity, data-subject tooling", names(ext, rec)],
        ["**Full**", "Everything in this backlog, including optional modules", names(full, ext)],
    ]
    counts = [[n, len(b)] for n, b in (("Core", core), ("Recommended", rec), ("Extended", ext), ("Full", full))]
    t = md_table(["Package", "What it gives Astex", "Adds these modules"], rows)
    return t + "\n\nModules per package: " + ", ".join(f"{n} {c}" for n, c in counts) + ". All packages are dependency-complete (checked by `tools/build_docs.py`)."


def homework():
    rows = []
    for m in MODS:
        if m["part"] == "A":
            continue
        rows.append([m["id"], m["name"], "; ".join(m["needs"])])
    return md_table(["Module", "Name", "Astex must supply"], rows)


def summary():
    part_counts = Counter(m["part"] for m in MODS)
    tiers = {p: Counter(m["tier"] for m in MODS if m["part"] == p) for p in "ABC"}
    rows = [
        ["A. Core", part_counts["A"], "3 core modules (platform, finance, HR)", len([1 for s in SCREENS if BY_ID[s["m"]]["part"] == "A"])],
        ["B. Conditional", part_counts["B"], f"R1: {tiers['B']['R1']}, O: {tiers['B']['O']}", len([1 for s in SCREENS if BY_ID[s["m"]]["part"] == "B"])],
        ["C. Suggested", part_counts["C"], f"R1: {tiers['C']['R1']}, R2: {tiers['C']['R2']}, O: {tiers['C']['O']}", len([1 for s in SCREENS if BY_ID[s["m"]]["part"] == "C"])],
    ]
    return "### Summary\n\n" + md_table(["Part", "Modules", "Tiers", "Screens"], rows) + f"\n\nTotal: {len(MODS)} modules and {len(SCREENS)} screens."


def parked():
    return "\n".join(f"- **{p['name']}** ({p['ref']}): {p['why']}" for p in mods_data["parked"])


def build_backlog():
    tpl = (ROOT / "docs/src/01-backlog.template.md").read_text(encoding="utf-8")
    repl = {
        "{{SUMMARY}}": summary(), "{{B_OVERVIEW}}": overview("B"), "{{B_CARDS}}": cards("B"),
        "{{C_OVERVIEW}}": overview("C"), "{{C_CARDS}}": cards("C"), "{{DEPS}}": deps(),
        "{{BUNDLES}}": bundles(), "{{HOMEWORK}}": homework(), "{{PARKED}}": parked(),
    }
    for k, v in repl.items():
        tpl = tpl.replace(k, v)
    (ROOT / "docs/01-backlog.md").write_text(tpl, encoding="utf-8")


def part_tag(mid):
    m = BY_ID[mid]
    return f"{m['part']} / {mid}" + ("" if m["tier"] in ("core",) else f" ({m['tier']})")


def build_screen_list():
    groups = []
    for s in SCREENS:
        if s["g"] not in groups:
            groups.append(s["g"])
    out = [
        "# Astex HR and Finance Platform: Screen List",
        "",
        "Task 3 companion to the clickable mockup (`mockup/index.html`). Version 0.1, 2 November 2026.",
        "",
        "Every screen carries the Part letter and module ID it belongs to. The mockup hides or greys screens whose module is not in the selected package, so Astex can see exactly what each choice adds.",
        "",
        "## Conventions",
        "",
        "- **Part A** screens belong to the core and are always present. **Part B** and **Part C** screens belong to optional modules.",
        "- Screens are described by purpose and key elements only. Visual detail is in the mockup.",
        "- The **Worker form** group is the public mobile form opened from an invitation link. It has no menu and no sign-in.",
        "- Roles: " + "; ".join(f"**{k}** {v}" for k, v in ROLES.items()) + ".",
        "- Journey IDs refer to `docs/02-user-journeys.md`.",
        "",
        "## Summary",
        "",
    ]
    rows = []
    for g in groups:
        sc = [s for s in SCREENS if s["g"] == g]
        c = Counter(BY_ID[s["m"]]["part"] for s in sc)
        rows.append([g, len(sc), c["A"], c["B"], c["C"]])
    rows.append(["**Total**", len(SCREENS), sum(r[2] for r in rows), sum(r[3] for r in rows), sum(r[4] for r in rows)])
    out.append(md_table(["Group", "Screens", "Part A", "Part B", "Part C"], rows))
    out.append("")
    out.append("## Navigation structure")
    out.append("")
    for g in groups:
        if g in ("Auth", "Worker form"):
            continue
        out.append(f"- **{g}**")
        sections = []
        for s in SCREENS:
            if s["g"] == g and s["s"] not in sections:
                sections.append(s["s"])
        for sec in sections:
            items = [f"{s['t']} [{BY_ID[s['m']]['part']}]" for s in SCREENS if s["g"] == g and s["s"] == sec]
            label = sec if sec else "(top level)"
            out.append(f"    - {label}: " + "; ".join(items))
    out.append("")
    for g in groups:
        out.append(f"## {g}")
        out.append("")
        sc = [s for s in SCREENS if s["g"] == g]
        rows = [[s["id"], s["t"], part_tag(s["m"]), ", ".join(s["r"]), s["p"], s["e"], ", ".join(s["j"])] for s in sc]
        out.append(md_table(["ID", "Screen", "Part / module", "Roles", "Purpose", "Key elements", "Journeys"], rows))
        out.append("")
    out.append("## Screens that are panels, not pages")
    out.append("")
    out.append("- **C13 Supplier VAT number validation** has no page of its own. Its result shows as a panel inside S-A19 Supplier detail.")
    out.append("- **Search box** is in the top bar of every signed-in screen and opens S-A03.")
    out.append("- **Notes and timeline** appear as a tab on every detail screen (S-A14, S-A16, S-A19, S-A32).")
    out.append("")
    (ROOT / "docs/03-screen-list.md").write_text("\n".join(out), encoding="utf-8")


def build_csv():
    with open(ROOT / "data/module-catalog.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "part", "area", "name", "tier", "requires", "uses_if_present", "plan_refs", "screens", "effort_low_h", "effort_likely_h", "effort_high_h"])
        for m in MODS:
            w.writerow([m["id"], m["part"], m["group"], m["name"], m["tier"], " ".join(m["requires"]), " ".join(m["optional"]), " ".join(m["refs"]),
                        " ".join(s["id"] for s in screens_of(m["id"])), "", "", ""])


if __name__ == "__main__":
    build_backlog()
    build_screen_list()
    build_csv()
    print("built docs/01-backlog.md, docs/03-screen-list.md, data/module-catalog.csv")
