#!/usr/bin/env python3
"""Build mockup/index.html: one self-contained file from data/*.json and mockup/src/*.

Run from the repository root:  python3 tools/build_mockup.py
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "mockup/src"
mods = json.loads((ROOT / "data/modules.json").read_text(encoding="utf-8"))
scr = json.loads((ROOT / "data/screens.json").read_text(encoding="utf-8"))
data = {"modules": mods["modules"], "screens": scr["screens"], "roles": scr["roles"], "parked": mods.get("parked", [])}

css = (SRC / "style.css").read_text(encoding="utf-8")
order = ["core.js", "screens_fin.js", "screens_hr.js", "screens_bc.js"]
js = "\n".join((SRC / f).read_text(encoding="utf-8") for f in order)

# safety: every screen in screens.json must have a renderer
ids = [s["id"] for s in scr["screens"]]
missing = [i for i in ids if f"'{i}'" not in js]
if missing:
    print("WARNING: no renderer found for", ", ".join(missing))

html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Astex HR and Finance: clickable mockup</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600&display=swap" rel="stylesheet">
<style>
{css}
</style>
</head>
<body>
<div id="root"></div>
<script>window.DATA = {json.dumps(data, ensure_ascii=False)};</script>
<script>
{js}
window.start();
</script>
</body>
</html>
"""
out = ROOT / "mockup/index.html"
out.write_text(html, encoding="utf-8")
print(f"built {out.relative_to(ROOT)} ({len(html)//1024} KB, {len(ids)} screens, {len(data['modules'])} modules)")
