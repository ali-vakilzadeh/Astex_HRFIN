/* Astex mockup core: state, helpers, shell, router. No backend; all data is sample data. */
(function () {
  'use strict';
  const D = window.DATA;
  const MODS = D.modules, SCR = D.screens, ROLES = D.roles;
  const BY = Object.fromEntries(MODS.map(m => [m.id, m]));
  const SBY = Object.fromEntries(SCR.map(s => [s.id, s]));
  const PART = { A: 'Core', B: 'Conditional', C: 'Suggested' };
  const PKGS = ['Core', 'Recommended', 'Extended', 'Full'];
  const R = {};          // screen renderers: R[id] = ctx => html
  const ACT = {};        // click actions by name
  const S = {
    pkg: 'Recommended', sel: new Set(), role: 'ACC', showLocked: true, lang: 'EN',
    tab: {}, open: { Home: true, Finance: true }, route: 'S-A01', arg: '', q: '', st: {}, navOpen: false
  };

  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const n = x => String(Math.round(x)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const $ = (q, r) => (r || document).querySelector(q);
  const $$ = (q, r) => Array.from((r || document).querySelectorAll(q));

  /* ---------- packages and modules ---------- */
  function pkgIds(name) {
    const A = MODS.filter(m => m.part === 'A').map(m => m.id);
    const t = tier => MODS.filter(m => m.part !== 'A' && m.tier === tier).map(m => m.id);
    if (name === 'Core') return A;
    if (name === 'Recommended') return A.concat(t('R1'));
    if (name === 'Extended') return A.concat(t('R1'), t('R2'));
    return MODS.map(m => m.id);
  }
  function setPkg(name) { S.pkg = name; S.sel = new Set(pkgIds(name)); }
  function detectPkg() {
    for (const p of PKGS) {
      const ids = pkgIds(p);
      if (ids.length === S.sel.size && ids.every(i => S.sel.has(i))) { S.pkg = p; return; }
    }
    S.pkg = 'Custom';
  }
  const has = id => S.sel.has(id);
  function addMod(id, out) {
    if (S.sel.has(id)) return;
    S.sel.add(id); out.push(id);
    BY[id].requires.forEach(r => addMod(r, out));
  }
  function dropMod(id, out) {
    if (!S.sel.has(id) || BY[id].part === 'A') return;
    S.sel.delete(id); out.push(id);
    MODS.forEach(m => { if (m.requires.includes(id)) dropMod(m.id, out); });
  }
  function toggleMod(id, on) {
    const out = [];
    on ? addMod(id, out) : dropMod(id, out);
    detectPkg();
    const extra = out.filter(x => x !== id);
    toast((on ? 'Added ' : 'Removed ') + id + ' ' + BY[id].name + (extra.length ? '. Also ' + (on ? 'added (required): ' : 'removed (depends on it): ') + extra.join(', ') : ''));
  }
  const roleOk = s => s.r.includes('ALL') || s.r.includes(S.role);
  const tag = (p, big) => `<span class="tag p${p}${big ? ' big' : ''}" title="Part ${p}: ${PART[p]}">${p}</span>`;

  /* ---------- html helpers ---------- */
  const chip = (t, k) => `<span class="chip${k ? ' ' + k : ''}">${t}</span>`;
  const ok = t => chip(t, 'ok'), wn = t => chip(t, 'warn'), er = t => chip(t, 'err'), inf = t => chip(t, 'info');
  const btn = (l, cls, a) => `<button class="btn ${cls || ''}" ${a || ''}>${l}</button>`;
  const tbtn = (l, msg, cls) => btn(l, cls, `data-toast="${esc(msg)}"`);
  const lnk = (t, go) => `<a class="lnk" href="#${go}">${t}</a>`;
  const sec = (title, body, sub, count) => `<section class="sec"><h2>${title}${count != null ? `<span class="n">${count}</span>` : ''}</h2>${sub ? `<p class="sub">${sub}</p>` : ''}${body}</section>`;
  const note = (t, k) => `<div class="note ${k || ''}">${t}</div>`;
  const kpis = a => `<div class="kpis">${a.map(k => `<div class="kpi ${k.k || ''}"><div class="v">${k.v}</div><div class="l">${k.l}</div>${k.s ? `<div class="s">${k.s}</div>` : ''}</div>`).join('')}</div>`;
  const tbl = (cols, rows, o) => {
    o = o || {};
    const th = cols.map(c => { const r = c[0] === '>'; return `<th${r ? ' class="num"' : ''}>${r ? c.slice(1) : c}</th>`; }).join('');
    const tb = rows.map((r, i) => {
      const g = o.go && o.go(r, i);
      return `<tr${g ? ` data-go="${g}" tabindex="0"` : ''}>` + r.map((c, j) => `<td${cols[j][0] === '>' ? ' class="num"' : ''}>${c}</td>`).join('') + '</tr>';
    }).join('');
    return `<table class="tbl${o.cls ? ' ' + o.cls : ''}"><thead><tr>${th}</tr></thead><tbody>${tb}</tbody></table>`;
  };
  const bars = (rows, alt) => `<div class="bars">${rows.map(r => `<div class="bar${alt ? ' alt' : ''}"><span>${r[0]}</span><span class="t"><i style="width:${r[1]}%"></i></span><span class="num">${r[2]}</span></div>`).join('')}</div>`;
  const cols = (rows, hi) => `<div class="cols">${rows.map((r, i) => `<div class="c${i === hi ? ' hi' : ''}"><b>${r[2]}</b><i style="height:${r[1]}%"></i><span>${r[0]}</span></div>`).join('')}</div>`;
  const tl = rows => `<div class="tl">${rows.map(r => `<div><span class="w">${r[0]}</span><span>${r[1]}</span></div>`).join('')}</div>`;
  const kv = rows => `<div class="kv">${rows.map(r => `<div><div class="k">${r[0]}</div><div class="v">${r[1]}</div></div>`).join('')}</div>`;
  const tools = (l, r) => `<div class="tools">${l || ''}<span class="grow"></span>${r || ''}</div>`;
  const flt = t => `<span class="flt">${t}</span>`;
  const search = (ph, key) => { key = key || S.route; return `<input id="q-${key}" data-keep placeholder="${ph || 'Search'}" aria-label="${ph || 'Search'}" value="${esc(S.st['f:' + key] || '')}" data-filter="${key}">`; };
  /* form field: f(label, value, kind, opts) */
  function f(l, v, k, o) {
    o = o || {}; k = k || 'text';
    const w = o.w ? ' w' : '';
    const id = 'f' + Math.random().toString(36).slice(2, 7);
    const hint = o.hint ? `<span class="hint">${o.hint}</span>` : '';
    if (k === 'chk') return `<div class="fld chk${w}"><input type="checkbox" id="${id}" ${v ? 'checked' : ''}><label for="${id}">${l}</label></div>`;
    let inp;
    if (k === 'select') inp = `<select id="${id}">${o.opts.map(x => `<option${x === v ? ' selected' : ''}>${x}</option>`).join('')}</select>`;
    else if (k === 'area') inp = `<textarea id="${id}">${esc(v || '')}</textarea>`;
    else if (k === 'mask') inp = `<div class="maskrow"><input id="${id}" value="${esc(v)}" readonly>${btn('Show (logged)', 'sm', 'data-toast="Identifier shown. This view is written to the audit log with your name and reason."')}</div>`;
    else inp = `<input id="${id}" type="${o.type || 'text'}" value="${esc(v == null ? '' : v)}"${o.ro ? ' readonly' : ''}${o.ph ? ` placeholder="${o.ph}"` : ''}>`;
    return `<div class="fld${w}"><label for="${id}">${l}</label>${inp}${hint}</div>`;
  }
  const form = (fields, c1) => `<div class="form${c1 ? ' c1' : ''}">${fields.join('')}</div>`;
  const tabs = (id, list, counts) => {
    const cur = S.tab[id] != null ? S.tab[id] : 0;
    return `<div class="tabs" role="tablist">${list.map((t, i) => `<button role="tab" aria-selected="${i === cur}" data-tab="${id}|${i}">${t}${counts && counts[i] != null ? `<span class="c">${counts[i]}</span>` : ''}</button>`).join('')}</div>`;
  };
  const tabIx = id => S.tab[id] != null ? S.tab[id] : 0;
  const split = (a, b, w) => `<div class="split" style="grid-template-columns:${w || '1.4fr 1fr'}"><div>${a}</div><div>${b}</div></div>`;
  /* plugin slot: only shown when the module is in the package */
  const slot = (mid, title, body) => {
    if (!has(mid)) return '';
    const p = BY[mid].part;
    return `<div class="slot ${p === 'B' ? 'b' : ''}"><div class="st">${tag(p)}<span>${mid} ${BY[mid].name}${title ? ': ' + title : ''}</span></div>${body}</div>`;
  };
  function ph(id, acts, title) {
    const s = SBY[id], m = BY[s.m];
    const rl = s.r.map(r => ROLES[r] || r).join(', ');
    return `<div class="ph">${tag(m.part, true)}<h1>${title || s.t}</h1><div class="acts">${acts || ''}</div></div>
<div class="meta"><span>${s.id}</span><span class="sep"></span><span>${m.id} ${m.name}</span><span class="sep"></span><span>${PART[m.part]} module${m.tier !== 'core' ? ', tier ' + m.tier : ''}</span><span class="sep"></span><span>${rl}</span></div>
<details class="about"><summary>About this screen</summary><div><p><b>Purpose.</b> ${s.p}</p><p><b>Key elements.</b> ${s.e}</p><p><b>Journeys.</b> ${s.j.join(', ') || 'none'}</p></div></details>`;
  }
  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast'; t.setAttribute('role', 'status'); t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3600);
  }
  function go(r) { location.hash = '#' + r; }

  /* ---------- list screen factory (data-driven screens) ---------- */
  /* cfg: acts, kpis, note, filters[], tabs[{n, cols, rows, go}], cols, rows, go, after (html), before (html), search */
  function L(id, cfg) {
    R[id] = ctx => {
      const c = typeof cfg === 'function' ? cfg(ctx) : cfg;
      let h = ph(id, c.acts);
      if (c.note) h += note(c.note, c.nk);
      if (c.kpis) h += kpis(c.kpis);
      if (c.before) h += c.before;
      if (c.tabs) {
        const ix = tabIx(id);
        const t = c.tabs[ix];
        h += tabs(id, c.tabs.map(x => x.n), c.tabs.map(x => x.rows ? x.rows.length : null));
        h += (c.filters || c.search) ? tools((c.filters || []).map(flt).join(' '), c.search ? search(c.search) : '') : '<div style="height:10px"></div>';
        h += t.pre || '';
        h += t.rows ? tbl(t.cols, filterRows(id, t.rows), { go: t.go }) : (t.html || '');
        if (t.rows) h += `<div class="foot">${filterRows(id, t.rows).length} of ${t.rows.length} shown</div>`;
      } else if (c.rows) {
        h += tools((c.filters || []).map(flt).join(' '), c.search ? search(c.search) : '');
        h += tbl(c.cols, filterRows(id, c.rows), { go: c.go });
        h += `<div class="foot">${filterRows(id, c.rows).length} of ${c.rows.length} shown</div>`;
      }
      if (c.after) h += c.after;
      return h;
    };
  }
  function filterRows(id, rows) {
    const q = (S.st['f:' + id] || '').toLowerCase();
    return q ? rows.filter(r => r.join(' ').replace(/<[^>]+>/g, '').toLowerCase().includes(q)) : rows;
  }

  /* ---------- shell ---------- */
  const NOMENU = new Set(['S-A00', 'S-A03', 'S-A13', 'S-A14', 'S-A16', 'S-A19', 'S-A32', 'S-A34', 'S-A35', 'S-A37', 'S-B04']);
  const GROUPS = ['Home', 'Finance', 'HR', 'Administration', 'Employee portal'];
  function menuItems(g) {
    const out = [];
    SCR.forEach(s => {
      if (s.g !== g || NOMENU.has(s.id)) return;
      if (S.role === 'EMP' ? g !== 'Employee portal' : g === 'Employee portal') return;
      if (!roleOk(s)) return;
      const off = !has(s.m);
      if (off && !S.showLocked) return;
      out.push({ s, off });
    });
    return out;
  }
  function currentGroup() { const s = SBY[S.route]; return s ? s.g : null; }
  function renderTop() {
    $('#top').innerHTML = `<button class="btn sm menu-btn" data-act="menu" aria-label="Menu">Menu</button>
<div class="brand">Astex<small>HR and finance</small></div>
<div class="search"><input id="gsearch" placeholder="Search invoices, suppliers, people, goods" aria-label="Search" value="${esc(S.q)}"></div>
<span class="grow"></span>
<label class="ctl">Package <select id="selpkg" aria-label="Package">${PKGS.concat(S.pkg === 'Custom' ? ['Custom'] : []).map(p => `<option${p === S.pkg ? ' selected' : ''}>${p}</option>`).join('')}</select></label>
<label class="ctl">Signed in as <select id="selrole" aria-label="Role">${['ACC', 'MGR', 'HRA', 'OWN', 'EXT', 'EMP'].map(r => `<option value="${r}"${r === S.role ? ' selected' : ''}>${ROLES[r]}</option>`).join('')}</select></label>
<label class="ctl"><input type="checkbox" id="chklock" ${S.showLocked ? 'checked' : ''}> Show locked</label>`;
  }
  function renderRail() {
    const cg = currentGroup();
    let h = '';
    GROUPS.forEach(g => {
      const items = menuItems(g);
      if (!items.length) return;
      const open = S.open[g] || cg === g;
      let body = '';
      const order = []; items.forEach(x => { if (!order.includes(x.s.s)) order.push(x.s.s); });
      const sorted = [].concat(...order.map(sn => items.filter(x => x.s.s === sn)));
      let lastSec = null;
      sorted.forEach(({ s, off }) => {
        if (s.s && s.s !== lastSec) body += `<div class="nav-s">${s.s}</div>`;
        lastSec = s.s;
        const act = s.id === S.route || (SBY[S.route] && ({ 'S-A13': 'S-A11', 'S-A14': 'S-A11', 'S-A16': 'S-A15', 'S-A19': 'S-A18', 'S-A32': 'S-A31', 'S-A34': 'S-A33', 'S-A35': 'S-A33', 'S-A37': 'S-A36', 'S-B04': 'S-B03' }[S.route] === s.id));
        body += `<a class="nav-i${act ? ' active' : ''}${off ? ' off' : ''}" href="#${s.id}"><span class="lbl">${s.t}</span>${tag(BY[s.m].part)}</a>`;
      });
      h += `<button class="nav-g${open ? ' open' : ''}" data-group="${g}">${g}<span class="cnt">${items.length}</span></button><div class="nav-body">${body}</div>`;
    });
    h += `<div class="nav-pub"><div class="row" style="margin-bottom:8px">${tag('A')} Core ${tag('B')} Conditional ${tag('C')} Suggested</div>
<div><a class="lnk" href="#S-A00">Sign-in screen</a></div><div style="margin-top:4px"><a class="lnk" href="#S-W01">Worker's phone form</a> (public link)</div></div>`;
    $('#rail').innerHTML = h;
    $('#rail').classList.toggle('open', S.navOpen);
  }
  function gate(s) {
    const m = BY[s.m];
    const miss = m.requires.filter(r => !has(r));
    return `<div class="ph">${tag(m.part, true)}<h1>${s.t}</h1></div>
<div class="gate"><h2>Not in the ${S.pkg} package</h2>
<p>This screen belongs to module <b>${m.id} ${m.name}</b> (${PART[m.part]}, tier ${m.tier}).</p>
<p>${m.summary}</p>
${miss.length ? `<p>It also needs: <b>${miss.map(x => x + ' ' + BY[x].name).join(', ')}</b>. Adding the module adds these too.</p>` : ''}
<p>What Astex provides for this module:</p><ul>${m.needs.map(x => `<li>${x}</li>`).join('')}</ul>
<div class="row">${btn('Add ' + m.id + ' to the package', 'pri', `data-addmod="${m.id}"`)}${btn('See module catalog', '', 'data-go="S-A58"')}</div></div>`;
  }
  function roleGate(s) {
    const need = s.r.filter(r => ROLES[r]).map(r => ROLES[r]).join(' or ');
    return `<div class="ph"><h1>${s.t}</h1></div><div class="gate"><h2>Not available for this role</h2><p>${s.id} is visible to: <b>${need}</b>. You are signed in as <b>${ROLES[S.role]}</b>.</p><p>Use the role selector in the top bar to see this screen as someone who has access.</p></div>`;
  }
  function parseHash() {
    const h = (location.hash || '').replace(/^#/, '');
    const [r, a] = h.split(':');
    S.route = SBY[r] ? r : (S.role === 'EMP' ? 'S-C28' : 'S-A01');
    S.arg = a || '';
  }
  function renderPage() {
    const s = SBY[S.route];
    const root = $('#root');
    const pub = s.g === 'Worker form' || s.id === 'S-A00';
    root.className = '';
    if (pub) {
      root.innerHTML = R[s.id]({ s, arg: S.arg });
      window.scrollTo(0, 0);
      return;
    }
    if (!$('#page')) buildShell();
    renderTop(); renderRail();
    const pg = $('#page');
    let h;
    if (!roleOk(s)) h = roleGate(s);
    else if (!has(s.m)) h = gate(s);
    else h = R[s.id] ? R[s.id]({ s, arg: S.arg }) : `<div class="ph"><h1>${s.t}</h1></div>`;
    pg.innerHTML = h;
    $('.main').scrollTop = 0;
    if (window.AFTER) window.AFTER();
  }
  function buildShell() {
    $('#root').innerHTML = `<div class="app"><header class="top" id="top"></header><nav class="rail" id="rail" aria-label="Main menu"></nav><main class="main"><div class="page" id="page"></div></main></div>`;
  }
  function render() { parseHash(); renderPage(); }
  function rerenderKeep() {
    const a = document.activeElement, id = a && a.id, pos = a && a.selectionStart;
    renderPage();
    if (id) { const e = document.getElementById(id); if (e) { e.focus(); try { e.setSelectionRange(pos, pos); } catch (x) { } } }
  }

  /* ---------- events ---------- */
  document.addEventListener('click', e => {
    const t = e.target;
    let el;
    if ((el = t.closest('[data-addmod]'))) { toggleMod(el.dataset.addmod, true); rerenderKeep(); return; }
    if ((el = t.closest('[data-act]'))) {
      const a = el.dataset.act;
      if (a === 'menu') { S.navOpen = !S.navOpen; renderRail(); return; }
      if (ACT[a]) { ACT[a](el, e); return; }
    }
    if ((el = t.closest('[data-group]'))) { const g = el.dataset.group; S.open[g] = !el.classList.contains('open'); el.classList.toggle('open'); return; }
    if ((el = t.closest('[data-tab]'))) { const [id, i] = el.dataset.tab.split('|'); S.tab[id] = +i; rerenderKeep(); return; }
    if ((el = t.closest('[data-toast]'))) { toast(el.dataset.toast); return; }
    if ((el = t.closest('[data-go]'))) { go(el.dataset.go); return; }
    if (t.closest('.nav-i')) { S.navOpen = false; }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const tr = e.target.closest && e.target.closest('tr[data-go]');
      if (tr) go(tr.dataset.go);
      if (e.target.id === 'gsearch') { S.q = e.target.value; go('S-A03'); }
    }
  });
  document.addEventListener('change', e => {
    const t = e.target;
    if (t.id === 'selpkg') { setPkg(t.value); toast(t.value + ' package: ' + S.sel.size + ' of ' + MODS.length + ' modules'); renderPage(); }
    else if (t.id === 'selrole') { S.role = t.value; const s = SBY[S.route]; if (S.role === 'EMP') go('S-C28'); else if (!roleOk(s) || s.g === 'Employee portal') go('S-A01'); renderPage(); }
    else if (t.id === 'chklock') { S.showLocked = t.checked; renderRail(); }
    else if (t.dataset && t.dataset.mod) { toggleMod(t.dataset.mod, t.checked); renderPage(); }
    else if (t.dataset && t.dataset.sel) { S.st[t.dataset.sel] = t.value; rerenderKeep(); }
  });
  document.addEventListener('input', e => {
    const t = e.target;
    if (t.dataset && t.dataset.filter) { S.st['f:' + t.dataset.filter] = t.value; rerenderKeep(); }
    if (t.dataset && t.dataset.rv && ACT.rvInput) ACT.rvInput(t);
  });
  document.addEventListener('focusin', e => { if (e.target.dataset && e.target.dataset.rv && ACT.rvFocus) ACT.rvFocus(e.target); });
  window.addEventListener('hashchange', () => { S.navOpen = false; render(); });

  window.H = { esc, n, $, $$, chip, ok, wn, er, inf, btn, tbtn, lnk, sec, note, kpis, tbl, bars, cols, tl, kv, tools, flt, search, f, form, tabs, tabIx, split, slot, ph, toast, go, tag, L, filterRows, render, renderPage, rerenderKeep };
  window.APP = { S, R, ACT, BY, SBY, MODS, SCR, ROLES, has, setPkg, toggleMod, PART };

  window.start = function () {
    setPkg('Recommended');
    if (!location.hash) location.hash = '#S-A01';
    render();
  };
})();
