/* Auth, home and finance core screens (Part A) */
(function () {
  const { n, chip, ok, wn, er, inf, btn, tbtn, lnk, sec, note, kpis, tbl, bars, cols, tl, kv, tools, flt, search, f, form, tabs, tabIx, split, slot, ph, toast, go, tag, L } = H;
  const { R, ACT, has, S, BY } = APP;

  const SUP = {
    dunai: 'Dunai Építőanyag Kft.', alfa: 'Alfa Szállítmányozás Zrt.', tisza: 'Tisza Gépipari Bt.', matra: 'Mátra Csomagolástechnika Kft.',
    budai: 'Budai Irodaszer Kft.', karpat: 'Kárpát Logisztika Kft.', duna: 'Duna Takarítás Kft.', szeged: 'Szeged Elektro Kft.', gyor: 'Győr Fémfeldolgozó Zrt.'
  };
  /* id, supplier, number, issued, due, gross, currency, status, case */
  const INV = [
    ['INV-1042', SUP.dunai, 'DÉ-2026/0873', '2026-10-26', '2026-11-25', 1498600, 'HUF', 'review', 'PC-2611'],
    ['INV-1041', SUP.alfa, 'ASZ-26-04417', '2026-10-30', '2026-11-29', 2310400, 'HUF', 'review', 'PC-2610'],
    ['INV-1040', SUP.budai, 'BI/2026/1188', '2026-10-30', '2026-11-14', 87450, 'HUF', 'review', '-'],
    ['INV-1039', SUP.karpat, 'KL-2026-0391', '2026-10-29', '2026-11-28', 4820, 'EUR', 'review', 'PC-2608'],
    ['INV-1038', SUP.tisza, 'TG-2026-212', '2026-10-28', '2026-11-12', 640100, 'HUF', 'open', 'PC-2607'],
    ['INV-1037', SUP.gyor, 'GYF/26/00934', '2026-10-27', '2026-11-26', 3118000, 'HUF', 'open', 'PC-2605'],
    ['INV-1036', SUP.matra, 'MCS-2026-0777', '2026-10-24', '2026-11-08', 412300, 'HUF', 'incomplete', 'PC-2603'],
    ['INV-1035', SUP.szeged, 'SZE-2026-1503', '2026-10-23', '2026-11-07', 195000, 'HUF', 'incomplete', 'PC-2602'],
    ['INV-1034', SUP.duna, 'DT-2026-0290', '2026-10-20', '2026-11-03', 238760, 'HUF', 'open', 'PC-2599'],
    ['INV-1033', SUP.alfa, 'ASZ-26-04302', '2026-10-15', '2026-11-14', 1870200, 'HUF', 'closed', 'PC-2594'],
    ['INV-1032', SUP.dunai, 'DÉ-2026/0861', '2026-10-12', '2026-11-11', 905000, 'HUF', 'closed', 'PC-2590'],
    ['INV-1031', SUP.budai, 'BI/2026/1102', '2026-10-09', '2026-10-24', 64300, 'HUF', 'closed', '-']
  ];
  const stChip = s => ({ review: wn('Needs review'), open: inf('Open'), incomplete: er('Incomplete'), closed: ok('Closed') }[s]);
  const money = (v, c) => n(v) + ' ' + c;
  window.DEMO = { SUP, INV, stChip, money };

  /* ---------- S-A00 sign in ---------- */
  R['S-A00'] = () => `<div class="login"><div class="box">
<div class="brand" style="margin-bottom:18px">Astex<small>HR and finance</small></div>
<h1>Sign in</h1><p class="mut" style="margin:0 0 6px">Use your work email. You will be asked for a code from your authenticator app.</p>
<div class="fld"><label for="em">Email</label><input id="em" value="anna.kovacs@astex.example"></div>
<div class="fld"><label for="pw">Password</label><input id="pw" type="password" value="correct horse"></div>
<div class="row" style="margin-top:6px"><button class="btn pri" data-go="S-A01">Continue</button><span class="mut">Step 1 of 2</span></div>
<hr style="border:0;border-top:1px solid var(--rule2);margin:20px 0">
<div class="fld"><label for="mf">Authenticator code</label><div class="code" style="margin:0"><input maxlength="1" value="4" aria-label="digit 1"><input maxlength="1" value="8" aria-label="digit 2"><input maxlength="1" value="1" aria-label="digit 3"><input maxlength="1" value="" aria-label="digit 4"><input maxlength="1" value="" aria-label="digit 5"><input maxlength="1" value="" aria-label="digit 6"></div></div>
<div class="msg err" style="margin-top:14px"><b>Account locked for 15 minutes.</b> Five wrong passwords in a row. Ask the platform owner to unlock it sooner.<br><span class="mut">Shown only after five failed attempts.</span></div>
<div class="row" style="margin-top:12px"><button class="btn sm" data-toast="Language set to English">EN</button><button class="btn sm" data-toast="A nyelv magyarra váltott (Hungarian labels ship with the build)">HU</button><a class="lnk" href="#S-A01" style="margin-left:auto">Skip to the app (mockup)</a></div>
</div></div>`;

  /* ---------- S-A01 home ---------- */
  const TASKS = {
    ACC: [
      ['Review invoice', lnk('INV-1042 Dunai Építőanyag, 1 498 600 HUF', 'S-A13'), wn('Low confidence: gross'), 'Today'],
      ['Review invoice', lnk('INV-1041 Alfa Szállítmányozás, 2 310 400 HUF', 'S-A13'), inf('OCR done'), 'Today'],
      ['Check match', lnk('Delivery note CMR-8812 against 3 cases', 'S-A17'), wn('Two candidates'), 'Today'],
      ['Complete case', lnk('PC-2603 Mátra Csomagolás: delivery note missing', 'S-A16'), er('Overdue 2 days'), '31 Oct'],
      ['Mark paid', lnk('INV-1034 Duna Takarítás, due 3 Nov', 'S-A21'), wn('Due tomorrow'), '3 Nov']
    ],
    MGR: [
      ['Approve invoice', lnk('INV-1037 Győr Fémfeldolgozó, 3 118 000 HUF', 'S-C01'), wn('Above 2 000 000 limit'), 'Today'],
      ['Approve batch', lnk('Payment batch 2026-11-03, 14 invoices, 9 214 880 HUF', 'S-C09'), inf('Waiting'), 'Today'],
      ['Approve bank change', lnk('Tisza Gépipari: new account', 'S-C03'), er('Payment on hold'), 'Today'],
      ['Read report', lnk('October payables by supplier', 'S-C14'), inf('Scheduled'), '5 Nov']
    ],
    HRA: [
      ['Review submission', lnk('Nguyen Van An: onboarding form submitted', 'S-A35'), inf('New'), 'Today'],
      ['Review document', lnk('Passport scan, Olena Kovalenko', 'S-A37'), wn('Low confidence: expiry'), 'Today'],
      ['Renew permit', lnk('Rashid Karimov: residence permit expires 21 Nov', 'S-A36'), er('19 days left'), '21 Nov'],
      ['Chase signature', lnk('Contract, Marlon Reyes, unsigned 6 days', 'S-A40'), wn('Unsigned'), '4 Nov']
    ],
    OWN: [
      ['Retry job', lnk('OCR job failed 3 times: scan 20261029-1412.pdf', 'S-A53'), er('Dead letter'), 'Today'],
      ['Approve deletion run', lnk('Retention: candidate documents older than 12 months', 'S-A56'), wn('Needs approval'), '5 Nov'],
      ['Invite user', lnk('Zsófia Nagy (accountant) waiting for activation', 'S-A50'), inf('Sent'), '-']
    ],
    EXT: [['Read report', lnk('October payables by supplier', 'S-C14'), inf('Shared with you'), '5 Nov']]
  };
  R['S-A01'] = () => {
    const t = TASKS[S.role] || TASKS.ACC;
    return ph('S-A01') +
      split(sec('Waiting for you', tbl(['Type', 'Item', 'Status', 'Due'], t), null, t.length) ,
        sec('Recent', tl([['10:42', 'You confirmed INV-1033 Alfa Szállítmányozás'], ['09:15', 'Email intake received 6 messages, 5 accepted'], ['Yesterday', 'Case PC-2594 closed as complete'], ['Yesterday', 'Supplier Tisza Gépipari: alias added']])), '1.5fr 1fr') +
      sec('My shortcuts', `<div class="row">${btn('Upload invoices', '', 'data-go="S-A12"')}${btn('Invoice register', '', 'data-go="S-A11"')}${btn('Task inbox', '', 'data-go="S-A02"')}${btn('Suppliers', '', 'data-go="S-A18"')}${btn('People', '', 'data-go="S-A31"')}</div>`);
  };

  /* ---------- S-A02 task inbox ---------- */
  L('S-A02', {
    acts: tbtn('Reassign selected', 'Selected tasks reassigned to Zsófia Nagy'),
    filters: ['Type: all', 'Owner: me', 'Due: this week', 'Overdue first'], search: 'Filter tasks',
    cols: ['Type', 'Item', 'Owner', 'Priority', 'Due', 'Status'],
    rows: [
      ['Review invoice', 'INV-1042 Dunai Építőanyag', 'Anna K.', 'High', '2 Nov', wn('Waiting')],
      ['Review invoice', 'INV-1041 Alfa Szállítmányozás', 'Anna K.', 'Normal', '2 Nov', wn('Waiting')],
      ['Check match', 'CMR-8812', 'Anna K.', 'Normal', '2 Nov', wn('Waiting')],
      ['Complete case', 'PC-2603 Mátra Csomagolás', 'Zsófia N.', 'High', '31 Oct', er('Overdue')],
      ['Mark paid', 'INV-1034 Duna Takarítás', 'Anna K.', 'Normal', '3 Nov', inf('Open')],
      ['Review document', 'Passport, Olena Kovalenko', 'Réka T. (HR)', 'High', '2 Nov', wn('Waiting')],
      ['Renew permit', 'Rashid Karimov', 'Réka T. (HR)', 'High', '21 Nov', er('19 days')]
    ],
    go: r => r[0].startsWith('Review inv') ? 'S-A13' : r[0].startsWith('Check') ? 'S-A17' : r[0].startsWith('Complete') ? 'S-A16' : r[0].startsWith('Mark') ? 'S-A21' : 'S-A36'
  });

  /* ---------- S-A03 search ---------- */
  R['S-A03'] = () => {
    const q = (S.q || '').trim();
    const hit = /rebar|betonac|ac[eé]l|steel|dunai|0873|hegeszt/i.test(q);
    let body;
    if (!q) body = note('Type in the search box at the top. Try <b>rebar</b>: it finds invoices written in Hungarian as <i>betonacél</i> through the goods dictionary.');
    else if (!hit) body = `<div class="gate"><h2>No results for "${q.replace(/</g, '')}"</h2><p>Check the spelling, remove a filter, or search a supplier tax number. Goods are searched in Hungarian and English.</p></div>`;
    else body = sec('Invoices', tbl(['Invoice', 'Supplier', 'Matched text', 'Found by'], [
      [lnk('INV-1042', 'S-A14'), SUP.dunai, '<mark>Betonacél</mark> B500B 12 mm, 6 tonna', chip('goods dictionary: rebar = betonacél', 'info')],
      [lnk('INV-1032', 'S-A14'), SUP.dunai, '<mark>Betonacél</mark> B500B 10 mm, 4 tonna', chip('goods dictionary', 'info')]
    ]), null, 2) + sec('Suppliers', tbl(['Supplier', 'Tax ID', 'Found by'], [[lnk(SUP.dunai, 'S-A19'), '14253698-2-13', chip('alias: Dunai Epitoanyag', 'info')]]), null, 1) +
      sec('Purchase cases', tbl(['Case', 'Title', 'Status'], [[lnk('PC-2611', 'S-A16'), 'Rebar delivery, Győr site', wn('Incomplete')]]), null, 1);
    return ph('S-A03') + tools(['All types', 'Any date', 'Any language'].map(flt).join(' '), '') + body;
  };

  /* ---------- S-A10 finance dashboard ---------- */
  R['S-A10'] = () => ph('S-A10', tbtn('Export', 'Dashboard exported as XLSX')) +
    kpis([{ v: '38,4 M', l: 'Spend this month (HUF)', s: 'October: 41,9 M' }, { v: '92%', l: 'Paid on time', s: 'target 95%', k: 'warn' }, { v: '7', l: 'Incomplete cases', s: '2 overdue', k: 'err' }, { v: '9', l: 'Review backlog', s: 'OCR 6, match 3', k: 'warn' }]) +
    split(sec('Spend by month', cols([['Jun', 52, '31,2'], ['Jul', 61, '36,8'], ['Aug', 48, '28,9'], ['Sep', 70, '42,3'], ['Oct', 69, '41,9'], ['Nov', 64, '38,4']], 5), 'Million HUF, invoices by issue date') ,
      sec('Top suppliers this month', bars([[SUP.alfa, 100, '9,8 M'], [SUP.gyor, 72, '7,1 M'], [SUP.dunai, 58, '5,7 M'], [SUP.tisza, 31, '3,0 M'], [SUP.matra, 22, '2,2 M']])), '1.2fr 1fr') +
    sec('Overdue payments', tbl(['Invoice', 'Supplier', '>Amount', 'Due', 'Days late'], [
      [lnk('INV-1029', 'S-A14'), SUP.karpat, '1 240 000 HUF', '2026-10-27', er('6')], [lnk('INV-1027', 'S-A14'), SUP.matra, '388 500 HUF', '2026-10-29', er('4')]]), null, 2);

  /* ---------- S-A11 invoice register ---------- */
  R['S-A11'] = () => {
    const names = ['New / Review', 'Open', 'Incomplete', 'Closed'], keys = ['review', 'open', 'incomplete', 'closed'];
    const ix = tabIx('S-A11');
    const all = INV;
    const rows = H.filterRows('S-A11', all.filter(r => r[7] === keys[ix]).map(r => r)).map(r => r);
    const body = rows.map(r => [lnk(r[0], r[7] === 'review' ? 'S-A13' : 'S-A14'), r[1], r[2], r[3], r[4], money(r[5], r[6]), stChip(r[7]), r[8] === '-' ? '<span class="mut">none</span>' : lnk(r[8], 'S-A16')]);
    return ph('S-A11', btn('Upload invoices', 'pri', 'data-go="S-A12"') + tbtn('Export view', 'Current view exported to XLSX (' + rows.length + ' rows)')) +
      tabs('S-A11', names, keys.map(k => all.filter(r => r[7] === k).length)) +
      tools(['Saved view: My open items', 'Supplier: all', 'Issued: last 30 days'].map(flt).join(' '), search('Search number, supplier, goods', 'S-A11')) +
      tbl(['Invoice', 'Supplier', 'Number', 'Issued', 'Due', '>Gross', 'Status', 'Case'], body, { go: (r, i) => rows[i][7] === 'review' ? 'S-A13' : 'S-A14' }) +
      `<div class="foot">${rows.length} invoices. Click a row to open it.${ix === 0 ? ' Rows waiting for review open in the review screen.' : ''}</div>`;
  };

  /* ---------- S-A12 upload ---------- */
  R['S-A12'] = () => ph('S-A12', tbtn('Start processing', '4 files queued. They appear in the register as Needs review.', 'pri')) +
    `<div class="split" style="grid-template-columns:1fr 1fr">
<div><div class="gate" style="max-width:none;text-align:center;border-style:dashed;padding:46px 20px"><h2>Drop invoices here</h2><p class="mut">PDF, JPG, PNG or ZIP. Up to 20 MB per file.</p>${btn('Choose files', '', 'data-toast="File picker opens here"')}</div>
${note('<b>Tip.</b> Files that look identical to one already uploaded are flagged before processing.')}</div>
<div>${tbl(['File', 'Role', 'Progress'], [
      ['DÉ-0873.pdf', 'Invoice', ok('Done')], ['Alfa-04417.pdf', 'Invoice', ok('Done')], ['cmr-8812.jpg', 'Delivery note / CMR', inf('Reading text 60%')], ['DÉ-0873-copy.pdf', 'Invoice', wn('Same file as DÉ-0873.pdf')]
    ])}${note('Choose the document role per file, or leave it on <b>Detect</b>. The system classifies invoices, order confirmations, delivery notes and proofs of payment.', 'ok')}</div></div>` +
    slot('B1', 'email intake', 'You can also forward invoices to <b>invoices@astex.example</b>. They arrive here without upload. ' + lnk('See intake monitor', 'S-B01'));

  /* ---------- S-A13 invoice review (OCR) ---------- */
  const RV0 = { sup: SUP.dunai, tax: '14253698-2-13', no: 'DÉ-2026/0873', date: '2026-10-26', due: '2026-11-25', cur: 'HUF', net: '1180000', vat: '318600', gross: '1489600', iban: 'HU42 1177 3016 1111 1018 0000 0000', type: 'Invoice', cc: '', acct: '', vcode: '', done: false };
  S.rv = Object.assign({}, RV0);
  const CONF = { sup: 98, tax: 97, no: 95, date: 96, due: 82, net: 94, vat: 93, gross: 61, iban: 90 };
  const hl = (k, t, extra) => `<span class="hl${CONF[k] < 70 ? ' low' : ''}" data-hl="${k}" tabindex="0">${t}</span>`;
  function rvCheck() {
    const r = S.rv, net = +r.net || 0, vat = +r.vat || 0, gross = +r.gross || 0;
    return { sum: net + vat, good: net + vat === gross };
  }
  function rvField(k, label, val, o) {
    o = o || {};
    const low = CONF[k] < 85;
    return `<div class="rf"><label for="rv-${k}">${label}</label>${o.opts ? `<select id="rv-${k}" data-rv="${k}">${o.opts.map(x => `<option${x === val ? ' selected' : ''}>${x}</option>`).join('')}</select>` : `<input id="rv-${k}" data-rv="${k}" value="${H.esc(val)}" class="${low ? 'low' : ''}">`}<span class="cf${low ? ' low' : ''}" id="cf-${k}">${CONF[k] ? CONF[k] + '%' : ''}</span></div>`;
  }
  R['S-A13'] = () => {
    const r = S.rv, c = rvCheck();
    const eur = r.cur === 'EUR';
    const sheet = `<div class="sheetwrap"><div class="sheet" aria-label="Original invoice"><div class="stamp${r.done ? ' show' : ''}" id="stamp">CONFIRMED</div>
<div class="lh"><div><h3>${hl('sup', SUP.dunai)}</h3><div>9026 Győr, Ipari út 14.</div><div>Adószám: ${hl('tax', '14253698-2-13')}</div></div><div style="text-align:right"><h3>SZÁMLA</h3><div>Számlaszám: ${hl('no', 'DÉ-2026/0873')}</div></div></div>
<table><tr><td>Kelte / Issue date</td><td class="r">${hl('date', '2026-10-26')}</td><td>Teljesítés</td><td class="r">2026-10-26</td></tr><tr><td>Fizetési határidő / Due</td><td class="r">${hl('due', '2026-11-25')}</td><td>Fizetési mód</td><td class="r">Átutalás</td></tr></table>
<table><thead><tr><th>Megnevezés</th><th class="r">Menny.</th><th class="r">Egységár</th><th class="r">Nettó</th></tr></thead><tbody>
<tr><td>Betonacél B500B 12 mm</td><td class="r">6 t</td><td class="r">140 000</td><td class="r">840 000</td></tr>
<tr><td>Hegesztőháló Q188</td><td class="r">40 db</td><td class="r">8 500</td><td class="r">340 000</td></tr></tbody></table>
<table style="width:60%;margin-left:auto"><tr><td>Nettó összesen</td><td class="r">${hl('net', '1 180 000')} HUF</td></tr><tr><td>ÁFA 27%</td><td class="r">${hl('vat', '318 600')} HUF</td></tr><tr><td><b>Fizetendő</b></td><td class="r"><b>${hl('gross', '1 498 600')} HUF</b></td></tr></table>
<p>Bankszámlaszám: ${hl('iban', 'HU42 1177 3016 1111 1018 0000 0000')}</p></div></div>`;
    const trans = `<div class="slot" style="border-style:solid;border-color:var(--rule)"><div class="st" style="color:var(--ink2)">${tag('A')}<span>Translation of the original (read-only)</span></div>
<table class="tbl"><thead><tr><th>Source (Hungarian)</th><th>English</th></tr></thead><tbody><tr><td>Betonacél B500B 12 mm</td><td>Rebar B500B 12 mm</td></tr><tr><td>Hegesztőháló Q188</td><td>Welded mesh Q188</td></tr><tr><td>Fizetendő</td><td>Amount due</td></tr></tbody></table><div class="hint mut" style="font-size:12px;margin-top:6px">Machine translation. The original text stays the legal record.</div></div>`;
    const dup = slot('C04', 'duplicate check', `<span class="chip ok">No duplicate found</span> Checked supplier + number, and amount + date within 14 days.`);
    const typ = has('C03') ? rvField('type', 'Document type', r.type, { opts: ['Invoice', 'Credit note', 'Correction', 'Pro forma'] }) : '';
    const rate = has('C06') ? `<div class="rf"><label>HUF equivalent</label><input value="${eur ? 'at 391,20 HUF/EUR (28 Oct rate)' : 'Not needed: invoice is in HUF'}" readonly><span class="cf"></span></div>` : '';
    const coding = slot('C05', 'coding', `<div class="rf"><label for="rv-cc">Cost centre</label><select id="rv-cc" data-rv="cc"><option value="">Choose…</option><option${r.cc === 'GY-100 Győr site' ? ' selected' : ''}>GY-100 Győr site</option><option>BP-200 Budapest office</option><option>SZ-300 Szeged site</option></select><span class="cf"></span></div>
<div class="rf"><label for="rv-acct">Account</label><select id="rv-acct" data-rv="acct"><option value="">Choose…</option><option${r.acct === '5110 Materials' ? ' selected' : ''}>5110 Materials</option><option>5210 Services</option><option>5410 Transport</option></select><span class="cf"></span></div>
<div class="rf"><label for="rv-vcode">VAT code</label><select id="rv-vcode" data-rv="vcode"><option value="">Choose…</option><option${r.vcode === 'A27 Domestic 27%' ? ' selected' : ''}>A27 Domestic 27%</option><option>A05 Domestic 5%</option><option>EU Reverse charge</option></select><span class="cf"></span></div>
<div class="hint mut" style="font-size:12px;margin-top:6px">Suggested from this supplier's last five invoices: GY-100, 5110, A27. ${btn('Accept suggestion', 'sm', 'data-act="rvAccept"')}</div>`);
    const confirmLabel = has('C01') ? 'Confirm and send for approval' : 'Confirm invoice';
    const ctrl = r.done
      ? `<div class="msg ok"><b>${has('C01') ? 'Sent for approval to Gábor Szűcs.' : 'Confirmed.'}</b> The case PC-2611 now shows the invoice. ${lnk('Open invoice', 'S-A14')} or ${lnk('review the next one', 'S-A11')}.</div>`
      : `<div id="rvmsg">${rvMsg(c)}</div><div class="row" style="margin-top:10px"><button class="btn pri" id="rvok" data-act="rvConfirm" ${c.good ? '' : 'disabled'}>${confirmLabel}</button>${btn('Save and leave', '', 'data-go="S-A11"')}${btn('Reject file', 'dng', 'data-toast="File rejected. Reason is required in the build."')}</div>`;
    return ph('S-A13') + `<div class="review"><div>${sheet}</div><div>
<div class="row" style="margin-bottom:8px"><b style="font:600 17px var(--serif)">Fields read from the document</b><span class="mut" style="margin-left:auto;font-size:12px">Confidence</span></div>
${rvField('sup', 'Supplier', r.sup)}${rvField('tax', 'Supplier tax ID', r.tax)}${rvField('no', 'Invoice number', r.no)}${typ}
${rvField('date', 'Issue date', r.date)}${rvField('due', 'Due date', r.due)}${rvField('cur', 'Currency', r.cur, { opts: ['HUF', 'EUR'] })}${rate}
${rvField('net', 'Net amount', r.net)}${rvField('vat', 'VAT amount', r.vat)}${rvField('gross', 'Gross amount', r.gross)}${rvField('iban', 'Bank account', r.iban)}
${coding}${dup}${trans}${ctrl}</div></div>`;
  };
  function rvMsg(c) {
    return c.good ? `<div class="msg ok">Net + VAT = gross. Ready to confirm.</div>` : `<div class="msg err"><b>Amounts do not add up.</b> Net + VAT is ${n(c.sum)} but gross reads ${n(+S.rv.gross || 0)}. Check the digits against the original.</div>`;
  }
  ACT.rvInput = el => {
    const k = el.dataset.rv; S.rv[k] = el.value;
    if (k === 'cur') { H.rerenderKeep(); return; }
    const c = rvCheck();
    const g = H.$('#rv-gross'); if (g) g.classList.toggle('bad', !c.good);
    const m = H.$('#rvmsg'); if (m) m.innerHTML = rvMsg(c);
    const b = H.$('#rvok'); if (b) b.disabled = !c.good;
    const cf = H.$('#cf-' + k); if (cf && CONF[k]) { cf.textContent = 'edited'; cf.classList.remove('low'); el.classList.remove('low'); }
  };
  ACT.rvFocus = el => { H.$$('.hl').forEach(h => h.classList.toggle('on', h.dataset.hl === el.dataset.rv)); };
  ACT.rvConfirm = () => { S.rv.done = true; H.renderPage(); const st = H.$('#stamp'); if (st) { st.classList.remove('show'); void st.offsetWidth; st.classList.add('show'); } };
  ACT.rvAccept = () => { S.rv.cc = 'GY-100 Győr site'; S.rv.acct = '5110 Materials'; S.rv.vcode = 'A27 Domestic 27%'; H.rerenderKeep(); toast('Coding suggestion accepted'); };
  document.addEventListener('click', e => {
    const h = e.target.closest && e.target.closest('.hl');
    if (h) { const i = H.$('#rv-' + h.dataset.hl); if (i) { i.focus(); i.select && i.select(); } }
  });
  ACT.rvReset = () => { S.rv = Object.assign({}, RV0); };

  /* ---------- S-A14 invoice detail ---------- */
  R['S-A14'] = () => {
    const ix = tabIx('S-A14');
    const t = ['Overview', 'Lines', 'Files and versions', 'Original and English text', 'Timeline'];
    const lines = tbl(['Description', 'Description (EN)', '>Qty', '>Unit price', '>Net'], [['Betonacél B500B 12 mm', 'Rebar B500B 12 mm', '6 t', '140 000', '840 000'], ['Hegesztőháló Q188', 'Welded mesh Q188', '40 pcs', '8 500', '340 000']]);
    const views = [
      kv([['Supplier', lnk(SUP.dunai, 'S-A19')], ['Invoice number', 'DÉ-2026/0873'], ['Issued', '2026-10-26'], ['Due', '2026-11-25'], ['Net', '1 180 000 HUF'], ['VAT 27%', '318 600 HUF'], ['Gross', '<b>1 498 600 HUF</b>'], ['Case', lnk('PC-2611', 'S-A16')], ['Payment', wn('Unpaid, due in 23 days')]]) +
      slot('C01', 'approval', `${ok('Approved')} by Gábor Szűcs on 2 Nov 10:12. Limit: up to 2 000 000 HUF.`) +
      slot('C05', 'coding', 'Cost centre GY-100 Győr site · Account 5110 Materials · VAT code A27') +
      slot('C03', 'related documents', 'No credit notes or corrections linked. ' + lnk('Open credit-note tool', 'S-C04')) +
      slot('C10', 'bookkeeping', wn('Ready to export') + ' Not yet in any export run.') +
      slot('C09', 'NAV cross-check', ok('Found in NAV') + ' Amounts and tax number agree.'),
      lines, tbl(['File', 'Role', 'Version', 'Uploaded'], [['DÉ-0873.pdf', 'Invoice', 'v1 (current)', '2 Nov 08:03 by email intake'], ['DÉ-0873.pdf', 'Invoice', 'v0', 'Replaced: wrong scan']]),
      `<div class="split" style="grid-template-columns:1fr 1fr;padding-top:14px"><div><b>Original (Hungarian)</b><p>Betonacél B500B 12 mm, 6 tonna<br>Hegesztőháló Q188, 40 db<br>Fizetendő: 1 498 600 Ft</p></div><div><b>English (machine translation)</b><p>Rebar B500B 12 mm, 6 tonnes<br>Welded mesh Q188, 40 pcs<br>Amount due: 1,498,600 HUF</p></div></div>`,
      tl([['2 Nov 10:12', 'Anna Kovács confirmed the invoice'], ['2 Nov 10:05', 'Anna Kovács changed gross from 1 489 600 to 1 498 600 (OCR misread)'], ['2 Nov 08:03', 'Received by email intake, text read, translated'], ['2 Nov 08:03', 'Linked to case PC-2611 by tax ID and order number']])
    ];
    return ph('S-A14', tbtn('Download original', 'Original file downloaded') + tbtn('Mark paid', 'Open Payment status to record the payment', '')) + tabs('S-A14', t) + `<div style="padding-top:16px">${views[ix]}</div>`;
  };

  /* ---------- S-A15 purchase cases ---------- */
  const CASES = [
    ['PC-2611', 'Rebar delivery, Győr site', SUP.dunai, wn('Processing'), 'Anna K.', '<span class="chip ok">Order</span> <span class="chip ok">Invoice</span> <span class="chip err">Delivery note</span>'],
    ['PC-2610', 'Transport Budapest to Győr', SUP.alfa, wn('Processing'), 'Anna K.', '<span class="chip ok">Order</span> <span class="chip ok">Invoice</span> <span class="chip ok">CMR</span>'],
    ['PC-2603', 'Packaging film', SUP.matra, er('Incomplete'), 'Zsófia N.', '<span class="chip ok">Order</span> <span class="chip ok">Invoice</span> <span class="chip err">Delivery note</span>'],
    ['PC-2602', 'Electrical works', SUP.szeged, er('Incomplete'), 'Zsófia N.', '<span class="chip err">Order</span> <span class="chip ok">Invoice</span>'],
    ['PC-2599', 'Office cleaning, October', SUP.duna, inf('Ready'), 'Anna K.', '<span class="chip ok">Contract</span> <span class="chip ok">Invoice</span>'],
    ['PC-2594', 'Transport September', SUP.alfa, ok('Closed'), 'Anna K.', '<span class="chip ok">All documents</span>']
  ];
  L('S-A15', { acts: tbtn('New case', 'Empty case created (cases normally form automatically)'), filters: ['State: all', 'Owner: all', 'Missing: any'], search: 'Search cases', cols: ['Case', 'Title', 'Supplier', 'State', 'Owner', 'Documents'], rows: CASES, go: () => 'S-A16' });

  /* ---------- S-A16 case detail ---------- */
  R['S-A16'] = () => ph('S-A16', tbtn('Add document', 'File picker opens here')) +
    kv([['Case', 'PC-2611 Rebar delivery, Győr site'], ['Supplier', lnk(SUP.dunai, 'S-A19')], ['Owner', 'Anna Kovács'], ['Opened', '2026-10-21']]) + '<div style="height:22px"></div>' +
    kpis([{ v: 'Incomplete', l: 'Completeness', s: 'delivery note missing', k: 'err' }, { v: 'Consistent', l: 'Consistency', s: 'amounts and quantities agree', k: 'ok' }, { v: 'Unpaid', l: 'Payment', s: 'due 25 Nov', k: 'warn' }]) +
    split(sec('Documents by role', tbl(['Role', 'Status', 'Document'], [['Order confirmation', ok('Present'), 'OC-2026-3310.pdf'], ['Invoice', ok('Present'), lnk('DÉ-2026/0873', 'S-A14')], ['Delivery note / CMR', er('Missing'), btn('Link a document', 'sm', 'data-toast="Pick from unmatched documents"')], ['Proof of payment', '<span class="mut">Not expected yet</span>', '-']])),
      sec('Timeline', tl([['2 Nov', 'Invoice linked by tax ID and order number'], ['25 Oct', 'Order confirmation received'], ['21 Oct', 'Case opened from order']])), '1.5fr 1fr');

  /* ---------- S-A17 matching review ---------- */
  R['S-A17'] = () => ph('S-A17') + note('Delivery note <b>CMR-8812</b> could belong to two open cases. Compare the signals and choose.', 'warn') +
    tbl(['Signal', 'CMR-8812 says', 'PC-2611 Rebar, Győr (score 82)', 'PC-2610 Transport (score 64)'], [
      ['Supplier', SUP.dunai, ok('Same'), er('Different: ' + SUP.alfa)],
      ['Order number', 'OC-2026-3310', ok('Same'), er('OC-2026-3288')],
      ['Goods', 'Betonacél 6 t', ok('Rebar 6 t'), wn('Not stated')],
      ['Delivery date', '2026-10-27', ok('Within 2 days'), ok('Same day')],
      ['Delivery address', 'Győr, Ipari út 14.', ok('Same'), wn('Budapest')]
    ]) + `<div class="row" style="margin-top:14px">${tbtn('Link to PC-2611', 'CMR-8812 linked to PC-2611. Case completeness updated.', 'pri')}${tbtn('Link to PC-2610', 'CMR-8812 linked to PC-2610')}${tbtn('Create new case', 'New case created from CMR-8812')}${tbtn('Leave unmatched', 'Left in the unmatched pile')}</div>`;

  /* ---------- S-A18 suppliers ---------- */
  L('S-A18', { acts: tbtn('Add supplier', 'New supplier form opens'), search: 'Search name, tax ID or alias', filters: ['Country: all', 'Open invoices: any'], cols: ['Supplier', 'Tax ID', 'Country', '>Aliases', '>Open invoices', 'Last invoice'],
    rows: [[lnk(SUP.dunai, 'S-A19'), '14253698-2-13', 'HU', '3', '1', '2026-10-26'], [lnk(SUP.alfa, 'S-A19'), '10458831-2-44', 'HU', '2', '1', '2026-10-30'], [lnk(SUP.budai, 'S-A19'), '11930275-2-41', 'HU', '1', '1', '2026-10-30'], [lnk(SUP.karpat, 'S-A19'), 'HU 13774920', 'HU / RO', '4', '1', '2026-10-29'], [lnk(SUP.tisza, 'S-A19'), '22058816-2-06', 'HU', '2', '1', '2026-10-28'], [lnk(SUP.gyor, 'S-A19'), '10029583-2-08', 'HU', '1', '1', '2026-10-27'], [lnk(SUP.matra, 'S-A19'), '14661207-2-07', 'HU', '2', '1', '2026-10-24']] });

  /* ---------- S-A19 supplier detail ---------- */
  R['S-A19'] = () => {
    const ix = tabIx('S-A19');
    const t = ['Identity', 'Bank accounts', 'History', 'Goods and notes'];
    const v = [
      kv([['Name', SUP.dunai], ['Tax ID', '14253698-2-13'], ['Country', 'HU'], ['Address', '9026 Győr, Ipari út 14.'], ['Payment terms', '30 days']]) +
      sec('Controlled aliases', tbl(['Alias', 'Source', 'Added'], [['Dunai Epitoanyag Kft', 'OCR variant, approved', '2026-08-02'], ['DUNAI ÉPÍTŐANYAG', 'Capital letters', '2026-08-02'], ['Dunai Építőanyag Kereskedelmi Kft.', 'Order confirmation', '2026-09-14']])) +
      slot('C13', 'VAT number check', ok('Valid in NAV') + ' Checked 2 Nov 08:03 against the Hungarian tax authority. Name on file: "Dunai Építőanyag Kft." Result is stored with the check date.'),
      tbl(['Account', 'Valid from', 'Valid to', 'Status'], [['HU42 1177 3016 1111 1018 0000 0000', '2024-03-01', 'open-ended', ok('Current')], ['HU90 1040 4021 5050 5252 5555 1111', '2021-01-01', '2024-02-29', chip('Replaced')]]) +
      slot('C02', 'change control', 'A new account on an invoice is held until a second person confirms it. ' + lnk('Open bank-account changes', 'S-C03')),
      tbl(['Invoice', 'Issued', '>Gross', 'Status'], INV.filter(r => r[1] === SUP.dunai).map(r => [lnk(r[0], 'S-A14'), r[3], money(r[5], r[6]), stChip(r[7])])),
      sec('Recurring goods', `<p>Betonacél (rebar), hegesztőháló (welded mesh), kavics (gravel)</p>`) + sec('Notes', `<p class="mut">Delivers to the Győr site only. Always send delivery note by email.</p>`)
    ];
    return ph('S-A19', tbtn('Edit supplier', 'Edit form opens')) + tabs('S-A19', t) + `<div style="padding-top:16px">${v[ix]}</div>`;
  };

  /* ---------- S-A20 goods dictionary ---------- */
  L('S-A20', { acts: tbtn('Add term', 'New term form opens'), search: 'Search term', cols: ['Canonical term', 'Hungarian', 'English', '>Uses', 'Search preview'],
    rows: [['Rebar', 'betonacél, vasbeton acél', 'rebar, reinforcing steel', '38', btn('Preview', 'sm', 'data-go="S-A03"')], ['Welded mesh', 'hegesztőháló', 'welded mesh, wire mesh', '21', btn('Preview', 'sm', 'data-toast="12 invoices, 4 cases would be found"')], ['Pallet', 'raklap', 'pallet', '64', btn('Preview', 'sm', 'data-toast="40 invoices would be found"')], ['Cleaning service', 'takarítás', 'cleaning', '12', btn('Preview', 'sm', 'data-toast="12 invoices would be found"')]] });

  /* ---------- S-A21 payment status ---------- */
  R['S-A21'] = () => ph('S-A21') + note('Payment is recorded here by hand. ' + (has('B4') ? 'Payment files from the bank export mark these automatically.' : 'Add the bank file module to produce payment files for the bank.')) +
    tools(['Due: next 14 days', 'Status: unpaid'].map(flt).join(' '), '') +
    tbl(['Invoice', 'Supplier', '>Amount', 'Due', 'Status', ''], [
      [lnk('INV-1029', 'S-A14'), SUP.karpat, '1 240 000 HUF', '2026-10-27', er('Overdue 6 days'), btn('Mark paid', 'sm', 'data-toast="Paid on 2 Nov by Anna Kovács. Reference needed."')],
      [lnk('INV-1034', 'S-A14'), SUP.duna, '238 760 HUF', '2026-11-03', wn('Due tomorrow'), btn('Mark paid', 'sm', 'data-toast="Paid on 2 Nov by Anna Kovács. Reference needed."')],
      [lnk('INV-1036', 'S-A14'), SUP.matra, '412 300 HUF', '2026-11-08', inf('Open'), btn('Mark paid', 'sm', 'data-toast="Paid. Reference needed."')],
      [lnk('INV-1038', 'S-A14'), SUP.tisza, '640 100 HUF', '2026-11-12', inf('Open'), btn('Mark paid', 'sm', 'data-toast="Paid. Reference needed."')]
    ]) + sec('Record a payment', form([f('Paid on', '2026-11-02', 'text', { type: 'date' }), f('Bank reference', 'UTAL-26110201'), f('Amount paid', '238760'), f('Note (for part payments)', '', 'text', { ph: 'e.g. second half follows on 15 Nov' })]));
})();
