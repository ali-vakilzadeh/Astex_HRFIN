/* HR core (Part A) and the worker phone form */
(function () {
  const { n, chip, ok, wn, er, inf, btn, tbtn, lnk, sec, note, kpis, tbl, bars, cols, tl, kv, tools, flt, search, f, form, tabs, tabIx, split, slot, ph, toast, go, tag, L } = H;
  const { R, ACT, has, S } = APP;
  const prog = p => `<span style="display:inline-block;width:80px;height:8px;background:var(--rule2);vertical-align:middle"><i style="display:block;width:${p}%;height:100%;background:${p < 80 ? 'var(--warn)' : 'var(--ok)'}"></i></span> <span class="mut">${p}%</span>`;

  const PEOPLE = [
    ['Nguyen Van An', 'Vietnam', inf('Onboarding'), 'Réka T.', 70],
    ['Olena Kovalenko', 'Ukraine', ok('Active'), 'Réka T.', 95],
    ['Rashid Karimov', 'Uzbekistan', ok('Active'), 'Réka T.', 88],
    ['Marlon Reyes', 'Philippines', inf('Onboarding'), 'Dóra M.', 82],
    ['Ioana Popescu', 'Romania', ok('Active'), 'Dóra M.', 100],
    ['Bence Szabó', 'Hungary', ok('Active'), 'Dóra M.', 100],
    ['Kamal Hossain', 'Bangladesh', chip('Candidate'), 'Réka T.', 25],
    ['Tamás Varga', 'Hungary', wn('Leaving'), 'Dóra M.', 96]
  ];

  /* ---------- S-A30 HR dashboard ---------- */
  R['S-A30'] = () => ph('S-A30') + kpis([{ v: '9', l: 'Documents expiring in 30 days', s: '2 in the next 7', k: 'err' }, { v: '14', l: 'Missing documents', s: 'across 6 people', k: 'warn' }, { v: '3', l: 'Unsigned contracts', s: 'oldest 6 days', k: 'warn' }, { v: '5', l: 'Submitted, not yet reviewed', s: 'oldest 1 day' }]) +
    split(sec('Expiring documents by window', bars([['In 7 days', 18, '2'], ['In 14 days', 36, '4'], ['In 30 days', 80, '9'], ['In 60 days', 100, '12'], ['In 90 days', 120 > 100 ? 100 : 100, '14']]), 'Click a bar in the build to open the filtered list. ' ),
      sec('Open work by owner', bars([['Réka T.', 100, '11'], ['Dóra M.', 64, '7'], ['Unassigned', 18, '2']], true)), '1.3fr 1fr') +
    sec('Incomplete profiles', tbl(['Person', 'Status', 'Missing', 'Completeness'], PEOPLE.filter(p => p[4] < 85).map(p => [lnk(p[0], 'S-A32'), p[2], p[4] < 50 ? 'Contact, address, tax ID, TAJ' : 'Residence permit copy', prog(p[4])])), null, 4);

  /* ---------- S-A31 people ---------- */
  L('S-A31', { acts: btn('New invitation', 'pri', 'data-go="S-A34"') + tbtn('Export', 'People list exported (identifiers masked)'), search: 'Search name or nationality', filters: ['Status: all', 'Nationality: all', 'Owner: all', 'Completeness: any'],
    cols: ['Name', 'Nationality', 'Status', 'Owner', 'Completeness'], rows: PEOPLE.map(p => [lnk(p[0], 'S-A32'), p[1], p[2], p[3], prog(p[4])]) });

  /* ---------- S-A32 person profile ---------- */
  R['S-A32'] = () => {
    const t = ['Overview', 'Identity and permits', 'Documents', 'Onboarding', 'Contract', 'Timeline'];
    if (has('C20')) t.splice(5, 0, 'Employment');
    const ix = tabIx('S-A32'), name = t[ix];
    let v;
    if (name === 'Overview') v = kv([['Name', 'Rashid Karimov'], ['Nationality', 'Uzbekistan'], ['Status', ok('Active')], ['Owner', 'Réka T.'], ['Started', '2025-03-10'], ['Language', 'Russian, English']]) + '<div style="height:20px"></div>' + note('<b>Residence permit expires 21 Nov 2026</b> (19 days). A renewal task is open.', 'warn') +
      slot('C21', 'offboarding', 'No end date set. ' + lnk('Start offboarding', 'S-C21')) + slot('C22', 'medical, training and licences', wn('Forklift licence due 15 Dec') + ' ' + ok('Medical valid to 2027-03'));
    else if (name === 'Identity and permits') v = form([f('Legal name', 'Karimov Rashid'), f('Date of birth', '1991-07-14'), f('Passport number', 'FA•••••34', 'mask'), f('Passport expiry', '2030-02-02'), f('Tax ID', '8•••••••12', 'mask'), f('TAJ number', '•••-•••-•••', 'mask'), f('Residence permit', 'RP-HU-••••812'), f('Permit expiry', '2026-11-21')]) + note('Identifiers are masked. Showing one writes your name and reason to the audit log.');
    else if (name === 'Documents') v = tbl(['Document', 'Status', 'Valid until', 'Review'], [['Passport', ok('Confirmed'), '2030-02-02', 'OCR 97%'], ['Residence permit', wn('Expiring'), '2026-11-21', 'OCR 94%'], ['Address card', ok('Confirmed'), '2028-05-01', 'Entered by hand'], ['Employment contract', ok('Signed'), '-', 'Scan filed 2025-03-08']], { go: () => 'S-A37' });
    else if (name === 'Onboarding') v = tbl(['Step', 'Done', 'By'], [['Invitation sent', '2025-02-24', 'Réka T.'], ['Form submitted', '2025-02-27', 'Worker'], ['Submission approved', '2025-02-28', 'Réka T.'], ['Contract signed', '2025-03-08', 'Réka T.']]);
    else if (name === 'Contract') v = tbl(['Version', 'Template', 'Generated', 'Signed copy'], [['v2', 'Fixed-term, Russian/Hungarian', '2025-03-04', ok('Filed 2025-03-08')], ['v1', 'Fixed-term, English/Hungarian', '2025-03-01', chip('Replaced')]], { go: () => 'S-A40' });
    else if (name === 'Employment') v = tl([['2026-09-01', 'Assigned to customer Alfa Logisztika, Győr'], ['2025-12-01', 'Job category changed: warehouse operator to forklift driver'], ['2025-03-10', 'Started: warehouse operator, Kárpát Logisztika']]) + `<div class="foot">${lnk('Open employment and assignments', 'S-C20')}</div>`;
    else v = tl([['2 Nov', 'Renewal task created: residence permit'], ['14 Aug', 'Passport expiry confirmed by Réka T.'], ['2025-03-10', 'Status changed to Active']]);
    return ph('S-A32', tbtn('Edit', 'Edit mode opens') + tbtn('Add note', 'Note box opens')) + tabs('S-A32', t) + `<div style="padding-top:16px">${v}</div>`;
  };

  /* ---------- S-A33 invitations ---------- */
  L('S-A33', { acts: btn('New invitation', 'pri', 'data-go="S-A34"'), filters: ['Draft', 'Sent', 'Opened', 'Submitted', 'Approved'], search: 'Search name',
    cols: ['Person', 'Type', 'Status', 'Sent', 'Expires', ''], go: r => r[2].includes('Submitted') ? 'S-A35' : null,
    rows: [['Nguyen Van An', 'New worker, non-EU', inf('Submitted'), '2026-10-28', '2026-11-11', btn('Review', 'sm', 'data-go="S-A35"')], ['Marlon Reyes', 'New worker, non-EU', wn('Opened'), '2026-10-30', '2026-11-13', btn('Resend', 'sm', 'data-toast="Link sent again. Old link stays valid until expiry."') + ' ' + btn('Revoke', 'sm', 'data-toast="Link revoked. The worker sees a revoked-link page."')], ['Kamal Hossain', 'Candidate', chip('Sent'), '2026-11-01', '2026-11-15', btn('Copy link', 'sm', 'data-toast="Link copied"')], ['Ioana Popescu', 'New worker, EU', ok('Approved'), '2026-10-12', '-', ''], ['Dani Horváth', 'New worker, EU', chip('Draft'), '-', '-', btn('Send', 'sm', 'data-toast="Invitation sent"')]] });

  /* ---------- S-A34 new invitation ---------- */
  R['S-A34'] = () => ph('S-A34') + split(form([f('Full name', 'Kamal Hossain'), f('Email', 'kamal.hossain@example.com'), f('Language of the form', 'English', 'select', { opts: ['English', 'Hungarian', 'Russian', 'Ukrainian', 'Vietnamese', 'Romanian'] }), f('Onboarding type', 'New worker, non-EU', 'select', { opts: ['New worker, EU', 'New worker, non-EU', 'Candidate'] }), f('Link valid for', '14 days', 'select', { opts: ['7 days', '14 days', '30 days'] }), f('Privacy notice', 'Version 3, 2026-06-01', 'text', { ro: true }), f('Message to the worker', 'Hello Kamal, please fill in this form before your start date. It takes about 15 minutes.', 'area', { w: true })]) +
    `<div class="row" style="margin-top:14px">${tbtn('Send invitation', 'Invitation sent to kamal.hossain@example.com', 'pri')}${tbtn('Save as draft', 'Draft saved')}${btn('Cancel', '', 'data-go="S-A33"')}</div>`,
    sec('What the worker will be asked for', tbl(['Document', 'Requirement'], [['Passport', ok('Required')], ['Residence permit', ok('Required')], ['Work permit', ok('Required')], ['Address card', wn('Required after arrival')], ['Tax ID', chip('Optional')], ['TAJ number', chip('Optional')]]), 'From the requirement matrix for: non-EU, residence permit route, warehouse job.'), '1.4fr 1fr');

  /* ---------- S-A35 submission review ---------- */
  R['S-A35'] = () => ph('S-A35', tbtn('Approve submission', 'Approved. Profile is active and the requirement checklist is saved.', 'pri') + tbtn('Request completion', 'Worker receives a link to the missing items') + tbtn('Reopen', 'Reopened with reason')) +
    kv([['Person', 'Nguyen Van An'], ['Submitted', '2026-11-01 19:42'], ['Language', 'Vietnamese'], ['Privacy notice', 'v3 accepted']]) + '<div style="height:20px"></div>' +
    split(sec('Answers by section', tbl(['Section', 'Fields', 'Status'], [['Personal and identity', '9 of 9', ok('Complete')], ['Contact and address', '6 of 7', wn('Emergency contact phone missing')], ['Permits and compliance', '4 of 6', er('Work permit number missing')], ['Documents', '3 of 4', er('Residence permit copy missing')]])),
      sec('Documents', tbl(['Document', 'Reading', ''], [['Passport', ok('97%'), btn('Open', 'sm', 'data-go="S-A37"')], ['Photo', ok('Accepted'), ''], ['Address proof', wn('81%'), btn('Open', 'sm', 'data-go="S-A37"')]])), '1.3fr 1fr');

  /* ---------- S-A36 expiring documents ---------- */
  L('S-A36', { filters: ['Window: 90 days', 'Type: all', 'Owner: all'], search: 'Search person',
    kpis: [{ v: '2', l: 'Within 7 days', k: 'err' }, { v: '4', l: 'Within 14 days', k: 'warn' }, { v: '9', l: 'Within 30 days' }, { v: '14', l: 'Within 90 days' }],
    cols: ['Person', 'Document', 'Expires', '>Days left', 'Severity', 'Owner', ''], go: () => 'S-A37',
    rows: [['Rashid Karimov', 'Residence permit', '2026-11-21', '19', er('Critical'), 'Réka T.', btn('Open', 'sm', 'data-go="S-A37"')], ['Olena Kovalenko', 'Residence permit', '2026-11-26', '24', er('Critical'), 'Réka T.', btn('Open', 'sm', 'data-go="S-A37"')], ['Marlon Reyes', 'Passport', '2026-12-18', '46', wn('Soon'), 'Dóra M.', btn('Open', 'sm', 'data-go="S-A37"')], ['Ioana Popescu', 'Address card', '2027-01-09', '68', inf('Plan'), 'Dóra M.', btn('Open', 'sm', 'data-go="S-A37"')], ['Tamás Varga', 'Medical certificate', '2026-10-30', '-3', er('Overdue: reason needed'), 'Dóra M.', btn('Add reason', 'sm', 'data-toast="Reason required: e.g. leaving on 30 Nov, not renewed"')]] });

  /* ---------- S-A37 document review (OCR) ---------- */
  R['S-A37'] = () => {
    const c = { p_sur: 99, p_giv: 98, p_no: 96, p_nat: 99, p_dob: 95, p_exp: 58 };
    const h = (k, t) => `<span class="hl${c[k] < 70 ? ' low' : ''}" data-hl="${k}" tabindex="0">${t}</span>`;
    const rf = (k, l, v) => `<div class="rf"><label for="rv-${k}">${l}</label><input id="rv-${k}" data-rv="${k}" value="${v}" class="${c[k] < 85 ? 'low' : ''}"><span class="cf${c[k] < 85 ? ' low' : ''}">${c[k]}%</span></div>`;
    return ph('S-A37') + `<div class="review"><div class="sheetwrap"><div class="sheet" style="font-family:'Courier New',monospace;background:#F3EFE2;min-height:420px"><div style="text-align:center;letter-spacing:.12em;margin-bottom:16px">PASSPORT / PASZPORT · REPUBLIC OF UZBEKISTAN</div>
<table style="font-family:inherit"><tr><td>Surname</td><td>${h('p_sur', 'KARIMOV')}</td></tr><tr><td>Given names</td><td>${h('p_giv', 'RASHID')}</td></tr><tr><td>Passport no.</td><td>${h('p_no', 'FA 1234534')}</td></tr><tr><td>Nationality</td><td>${h('p_nat', 'UZBEKISTAN')}</td></tr><tr><td>Date of birth</td><td>${h('p_dob', '14 JUL 1991')}</td></tr><tr><td>Date of expiry</td><td>${h('p_exp', '02 FEB 2O30')}</td></tr></table>
<p style="margin-top:30px;letter-spacing:.1em">P&lt;UZBKARIMOV&lt;&lt;RASHID&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;<br>FA12345346UZB9107146M300202&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;04</p></div></div>
<div><div class="row" style="margin-bottom:8px"><b style="font:600 17px var(--serif)">Fields read from the scan</b><span class="mut" style="margin-left:auto;font-size:12px">Confidence</span></div>
${rf('p_sur', 'Surname', 'Karimov')}${rf('p_giv', 'Given names', 'Rashid')}${rf('p_no', 'Document number', 'FA1234534')}${rf('p_nat', 'Nationality', 'Uzbekistan')}${rf('p_dob', 'Date of birth', '1991-07-14')}${rf('p_exp', 'Expiry date', '2030-02-02')}
<div class="msg err"><b>Expiry date is uncertain.</b> The letter O in "2O30" was read as zero. The machine-readable lines agree with 2030-02-02. Confirm only after checking the scan.</div>
<div class="row" style="margin-top:10px">${tbtn('Confirm', 'Document confirmed. Expiry reminders set from 2030-02-02.', 'pri')}${tbtn('Reject scan', 'Scan rejected. Worker receives a request for a better photo.', 'dng')}${tbtn('Upload replacement', 'File picker opens here')}</div></div></div>`;
  };

  /* ---------- S-A38 requirement matrix ---------- */
  R['S-A38'] = () => {
    const rq = ok('Required'), op = chip('Optional'), no = '<span class="mut">-</span>';
    return ph('S-A38', tbtn('Save changes', 'Matrix saved as version 4', 'pri')) + note('Each cell says whether a document is needed for that kind of person. The invitation form and the checklist are built from this table. Changes are versioned.') +
      tools(['Job category: warehouse', 'Matrix version 3'].map(flt).join(' '), '') +
      tbl(['Document', 'EU citizen', 'Non-EU, residence permit', 'Non-EU, visa route', 'Candidate'], [
        ['Passport or ID card', rq, rq, rq, op], ['Residence permit', no, rq, no, no], ['Work permit', no, rq, rq, no], ['Visa', no, no, rq, no], ['Address card', rq, rq, rq, no], ['Tax ID', op, rq, rq, no], ['TAJ number', rq, rq, rq, no], ['Medical certificate', rq, rq, rq, no]]) +
      sec('Preview for a sample person', form([f('Nationality', 'Vietnam', 'select', { opts: ['Vietnam', 'Hungary', 'Ukraine', 'Romania'] }), f('Permit route', 'Residence permit', 'select', { opts: ['Residence permit', 'Visa route', 'None'] }), f('Job category', 'Warehouse operator', 'select', { opts: ['Warehouse operator', 'Forklift driver', 'Office'] }), f('Result', '7 required, 1 optional', 'text', { ro: true })]));
  };

  /* ---------- S-A39 duplicates ---------- */
  R['S-A39'] = () => ph('S-A39') + note('Two profiles share an email and a passport number. Compare before you merge.', 'warn') +
    tbl(['Field', 'Profile 1 (created 2025-03-02)', 'Profile 2 (created 2026-10-30)'], [['Name', 'Marlon Reyes', 'Reyes, Marlon S.'], ['Email', ok('marlon.reyes@example.com'), ok('marlon.reyes@example.com')], ['Passport number', ok('P1234567A'), ok('P1234567A')], ['Date of birth', '1993-04-11', '1993-04-11'], ['Phone', '+36 30 555 0192', wn('+63 917 555 0147')], ['Documents', '4', '1']]) +
    `<div class="row" style="margin-top:14px">${tbtn('Merge into profile 1', 'Merged. Profile 2 documents moved. The merge is in the audit log.', 'pri')}${tbtn('Link as related', 'Profiles linked')}${tbtn('Keep separate', 'Marked as different people')}</div>`;

  /* ---------- S-A40 contract generation ---------- */
  R['S-A40'] = () => ph('S-A40', tbtn('Generate PDF', 'Contract v3 generated from confirmed values', 'pri')) + split(
    form([f('Person', 'Marlon Reyes', 'select', { opts: ['Marlon Reyes', 'Nguyen Van An'] }), f('Template', 'Fixed-term contract, English/Hungarian', 'select', { opts: ['Fixed-term contract, English/Hungarian', 'Indefinite contract, Hungarian'] }), f('Start date', '2026-11-09', 'text', { type: 'date' }), f('Job title', 'Warehouse operator')], true) +
    sec('Versions', tbl(['Version', 'Generated', 'Status'], [['v3', 'Preview', chip('Not generated')], ['v2', '2026-10-31', er('Unsigned, 6 days')], ['v1', '2026-10-29', chip('Replaced')]]) + `<div class="row" style="margin-top:10px">${tbtn('Upload signed scan', 'File picker opens here')}${tbtn('Send reminder', 'Reminder sent to Marlon Reyes')}</div>`),
    `<div class="sheet" style="min-height:360px"><h3>Employment contract</h3><p class="mut">Preview with confirmed values. Fields that come from the profile are shaded.</p><p>Between <b>Astex Kft.</b> and <span class="hl">Marlon Reyes</span>, born <span class="hl">1993-04-11</span>, passport <span class="hl">P•••••7A</span>.</p><p>Job: <span class="hl">Warehouse operator</span>. Start: <span class="hl">2026-11-09</span>. Place of work: Győr.</p><p class="mut">Merge-field check: all 14 fields filled. 0 empty.</p></div>`, '1fr 1fr');

  /* ================= Worker phone form (public) ================= */
  const STEPS = ['S-W03', 'S-W04', 'S-W05', 'S-W06', 'S-W07'];
  function phone(id, o) {
    const ix = STEPS.indexOf(id);
    const steps = ix >= 0 ? `<div class="steps">${STEPS.map((s, i) => `<i class="${i <= ix ? 'd' : ''}"></i>`).join('')}</div><div class="stl">Step ${ix + 1} of 5</div>` : '';
    const jump = ['S-W01', 'S-W02', 'S-W03', 'S-W04', 'S-W05', 'S-W06', 'S-W07', 'S-W08'].map(s => `<a class="lnk" href="#${s}"${s === id ? ' style="font-weight:700"' : ''}>${s.slice(2)}</a>`).join(' ');
    return `<div class="pubbar">${tag('A')}<b>Worker's phone form</b><span>Public link from the invitation. No menu, no sign-in.</span><span style="margin-left:auto">Screens: ${jump}</span><a class="lnk" href="#S-A33">Back to the app</a></div>
<div class="pubwrap"><div class="phone"><div class="ph-h"><div class="co">Astex Kft.</div>${steps}</div><div class="ph-b"><h2>${o.title}</h2>${o.body}</div>${o.foot ? `<div class="ph-f">${o.foot}</div>` : ''}</div></div>`;
  }
  const nxt = (go, l) => btn(l || 'Continue', 'pri', `data-go="${go}"`), bck = go => btn('Back', '', `data-go="${go}"`);
  const fl = (l, v, k, o) => f(l, v, k, o);
  R['S-W01'] = () => phone('S-W01', { title: 'Welcome, Van An', body: `<p>Astex asks you to fill in this form before you start work. It takes about 15 minutes. You can stop and come back with the same link.</p>
<p><b>Have ready:</b></p><ul class="chkl"><li>Passport</li><li>Residence permit or visa</li><li>Address in Hungary</li><li>Tax ID and TAJ number, if you have them</li></ul>
${form([fl('Language', 'English', 'select', { opts: ['English', 'Tiếng Việt', 'Magyar'] })])}
<div class="fld chk" style="margin-top:14px"><input type="checkbox" id="pn"><label for="pn">I have read the privacy notice, version 3.</label></div><p><a class="lnk" href="#S-W01">Read the privacy notice</a></p>`, foot: nxt('S-W02', 'Start') });
  R['S-W02'] = () => phone('S-W02', { title: 'Enter the code', body: `<p>We sent a 6-digit code to <b>n•••@example.com</b>. It is valid for 10 minutes.</p><div class="code"><input maxlength="1" value="5"><input maxlength="1" value="0"><input maxlength="1" value="7"><input maxlength="1" value="2"><input maxlength="1" value=""><input maxlength="1" value=""></div><p class="mut">4 attempts left.</p><p>${btn('Send a new code', 'sm', 'data-toast="New code sent"')}</p>`, foot: bck('S-W01') + nxt('S-W03') });
  R['S-W03'] = () => phone('S-W03', { title: 'Personal details', body: form([fl('Legal name (as in passport)', 'Nguyen Van An'), fl('Former name', '', 'text', { ph: 'If different' }), fl('Date of birth', '1996-02-19', 'text', { type: 'date' }), fl('Place of birth', 'Hanoi'), fl("Mother's name", 'Tran Thi Lan'), fl('Nationality', 'Vietnam', 'select', { opts: ['Vietnam', 'Hungary', 'Other'] }), fl('Passport number', 'C1234567'), fl('Passport expiry', '2031-05-20', 'text', { type: 'date' })]), foot: bck('S-W02') + nxt('S-W04') });
  R['S-W04'] = () => phone('S-W04', { title: 'Contact and address', body: form([fl('Phone', '+36 30 555 0142'), fl('Permanent address', 'Hanoi, Cau Giay, 12 Nguyen Phong Sac'), fl('Address in Hungary', '9024 Győr, Szent István út 8.'), fl('Address card number', '', 'text', { ph: 'Add later if you have none yet' }), fl('Emergency contact', 'Nguyen Thi Hoa'), fl('Emergency contact phone', '', 'text', { ph: 'Required' })]) + `<div class="msg err">Emergency contact phone is required.</div>`, foot: bck('S-W03') + nxt('S-W05') });
  R['S-W05'] = () => phone('S-W05', { title: 'Permits and compliance', body: form([fl('Tax ID', '8412345678'), fl('TAJ number', '', 'text', { ph: 'If you have one' }), fl('Residence permit number', 'RP-••••-3391'), fl('Residence permit valid until', '2027-03-01', 'text', { type: 'date' }), fl('Work permit number', '', 'text', { ph: 'Required for your route' })]) + `<p class="mut" style="margin-top:12px">Visa questions are hidden because you hold a residence permit.</p>`, foot: bck('S-W04') + nxt('S-W06') });
  R['S-W06'] = () => phone('S-W06', { title: 'Upload documents', body: `<p>Take a clear photo. All four corners must be visible.</p><ul class="chkl"><li>Passport data page<span class="st">${ok('Uploaded')}</span></li><li>Passport photo<span class="st">${ok('Uploaded')}</span></li><li>Address proof<span class="st">${wn('Check: blurry')}</span></li><li>Residence permit<span class="st">${er('Missing')}</span></li></ul><div class="row" style="margin-top:14px">${btn('Take photo', 'pri', 'data-toast="Camera opens here"')}${btn('Choose file', '', 'data-toast="File picker opens here"')}${btn('Retake address proof', '', 'data-toast="Camera opens here"')}</div>`, foot: bck('S-W05') + nxt('S-W07') });
  R['S-W07'] = () => phone('S-W07', { title: 'Check and send', body: `<ul class="chkl"><li>Personal details<span class="st">${ok('Complete')}</span></li><li>Contact and address<span class="st">${wn('1 item missing')}</span></li><li>Permits<span class="st">${wn('1 item missing')}</span></li><li>Documents<span class="st">${wn('1 item missing')}</span></li></ul><p>You can send now and add the missing items later with the same link.</p><div class="fld chk"><input type="checkbox" id="cs" checked><label for="cs">I confirm that my answers are correct.</label></div><p class="mut">After you send, fields lock. Astex can reopen them if something needs fixing.</p>`, foot: bck('S-W06') + nxt('S-W08', 'Send to Astex') });
  R['S-W08'] = () => phone('S-W08', { title: 'Thank you', body: `<div class="msg ok"><b>Your form was sent</b> on 1 Nov at 19:42.</div><p>Astex will check it and contact you if something is missing. You do not need to do anything else now.</p><hr style="border:0;border-top:1px solid var(--rule2);margin:18px 0"><p class="mut"><b>Other states of this link</b> (used when someone opens it later):</p><ul style="color:var(--ink2);padding-left:18px"><li><b>Expired:</b> "This link has expired." No personal data is shown. Button: ask for a new link.</li><li><b>Revoked:</b> "This link is no longer active."</li><li><b>Already sent:</b> "Your form was already sent."</li></ul>`, foot: btn('Ask for a new link', '', 'data-toast="Request sent to Réka T. at Astex"') });
})();
