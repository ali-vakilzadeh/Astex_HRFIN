# Astex HR and Finance Platform: Scope and Requirements Backlog

Task 1 of the proposal. Version 0.1, 2 November 2026. Prepared from the Astex proposal document (11 of 13 pages received) and the earlier Requirements and Delivery Plan.

## 1. How this backlog is organised

The scope is split into three parts, so Astex can say yes or no to each piece instead of to one large project.

| Part | What it contains | How it is built and priced |
| --- | --- | --- |
| **A. Core** | Functions described in the Astex document and clear enough to build, plus a small set of cheap *extension points* that stop later modules forcing a redesign | One fixed scope |
| **B. Conditional modules** | Functions that are in the Astex document but depend on a format, access right or decision we do not have yet (bank file format, NAV and EKÁER access, mailbox set-up, bank API) | Plugin modules with a fixed contract; the outside-system adapter is estimated once its specification arrives |
| **C. Suggested additions** | Functions that are not in the Astex document but that this kind of operation almost always needs (approvals, accounting export, statement reconciliation, offboarding and so on) | Plugin modules with the same contract; each optional |

Every module has an ID (A1, B1, C01), a tier, and a list of other modules it requires:

| Tier | Meaning |
| --- | --- |
| **core** | Part A. Always delivered |
| **R1** | Recommended first wave. We expect Astex to need it at or soon after go-live |
| **R2** | Recommended later. Valuable, can follow once R1 is running |
| **O** | Optional. Only if Astex confirms the need |

Requirement IDs such as FI-25 or HR-10 refer to the numbered requirements in the Requirements and Delivery Plan document. They stay as cross-references so nothing in that document is lost. The plan's old B/R/E tags are replaced by the Part letters used here.

{{SUMMARY}}

## 2. Part A: core backlog

Source column: "Client p.N" means the Astex document page; "Plan" means added by us to protect the design.

### A1. Platform foundation

| ID | Story | Plan ref | Source | Done when |
| --- | --- | --- | --- | --- |
| A1.01 | Back-office users sign in with email and password; a second factor is mandatory | SH-02 | Client p.10 (MFA optional; we make it mandatory) | A sign-in without a second factor is impossible |
| A1.02 | Roles are built from permission sets per module and action; sensitive identifiers are masked by field | SH-03 | Client p.10 | Allow and deny tests pass for every role; each unmask is logged |
| A1.03 | Every create, change, delete and unmask is recorded with actor, role, source, before and after values, and a reason for overrides | SH-05 | Client p.10 | Any record's full history can be shown |
| A1.04 | Files are stored privately with original, versions, checksum and short-lived download links | SH-06 | Client p.2, 6, 9 | Replacing a file keeps the old version |
| A1.05 | Uploads are checked for type and size and pass a malware-scan hook before use | SH-07 | Client p.10 | An infected test file is quarantined |
| A1.06 | OCR runs through a provider-independent interface; one default provider is included; field value, confidence, source page and raw result are kept | SH-08 | Client p.4, 9 | The provider can be swapped by configuration |
| A1.07 | Background jobs move through queued, processing, review, completed, failed, retry and dead-letter, and every failure has an owner and a recovery action | SH-09 | Client p.10 | Fault-injection runs recover with no duplicates |
| A1.08 | Notifications appear in the app and by email with de-duplication and per-language templates | SH-12 | Client p.4 | One event never sends two identical emails |
| A1.09 | A task inbox lists every review, approval, expiry and exception with owner, due date and priority | SH-11 | Client p.4, 8 | No exception exists without an owner |
| A1.10 | Full-text search covers record fields, OCR text and English translations, with prefix, alias and synonym matching | SH-13 | Client p.8 | Searching "forklift" finds a Hungarian invoice for *targonca* |
| A1.11 | Every list has sort, filter, pagination, saved views and CSV/XLSX export that respects filters and masking | SH-14 | Client p.5 | An export equals the on-screen list |
| A1.12 | Administrators change document types, thresholds, reminder windows and templates without a release | SH-16 | Client p.4 | A new document requirement is added in the admin screen |
| A1.13 | The interface is available in Hungarian and English | SH-17 | Plan | Every screen and email exists in both |
| A1.14 | Retention rules per record category, legal hold, and deletion or anonymisation runs that need approval | SH-18 | Client p.10 | A record past retention is removed only after an approved run |
| A1.15 | Notes and one timeline on every main record | SH-19 | Client p.6 | A record's history shows in one place |
| A1.16 | A migration wizard imports Excel registers and scan folders, with a trial-load report of counts and totals | none | Client p.8 (goal only) | Each trial load reconciles and is signed by the module owner |
| A1.17 | The module host: modules register their menu slots, permissions, settings, events and adapters, and can be enabled per legal entity | EP-01 | Plan | A test module appears in the menu without changing core code |
| A1.18 | A workflow engine with states, transitions, approvers, deadlines and escalation, running a single-step default | EP-02 | Plan | An approval rule can be added later by configuration only |
| A1.19 | An event outbox and event catalog so modules react to recorded events | EP-07 | Plan | A new consumer is added without changing the producer |
| A1.20 | An adapter registry and credential vault: secrets are write-only, test and production are separate | EP-08 | Client p.9 (secrets server-side) | No secret is ever shown after saving |
| A1.21 | The organisation model carries legal entity and cost centre on every business row, even while Astex uses one of each | EP-03, SH-01 | Client p.9 (organisation ID) | A second entity can be added with no data migration |

### A2. Finance core

| ID | Story | Plan ref | Source | Done when |
| --- | --- | --- | --- | --- |
| A2.01 | Accountants upload invoices and related files by drag and drop; the same file is not loaded twice | FI-01 | Client p.5 | A repeated upload is flagged by checksum |
| A2.02 | OCR proposes the invoice fields Astex listed (supplier, tax ID, number, three dates, reference, subject, currency, net, VAT, gross, items, language) with confidence | FI-02 | Client p.5 | Field mapping confirmed on representative Astex invoices |
| A2.03 | A side-by-side review shows the original and editable values with validation messages | FI-03 | Client p.5 | Totals that do not add up block confirmation |
| A2.04 | After review, an English translation of the subject, items, line descriptions and relevant text is stored with the original and is searchable | FI-04 | Client p.5, 8 | Every confirmed invoice has a linked translation |
| A2.05 | The invoice register shows New/Review, Open, Incomplete and Closed views | FI-05 | Client p.5 | Each invoice appears in exactly one view |
| A2.06 | A supplier master with tax ID first, controlled aliases and effective-dated bank accounts | FI-13 | Client p.6 | Two spellings of one supplier resolve to one record |
| A2.07 | A goods dictionary of synonyms maintained by finance users | FI-14 | Client p.6, 8 | A new synonym works in search at once |
| A2.08 | Purchase cases link invoice, delivery note, EKÁER declaration, closing document and other files; states New, Processing, Incomplete, Ready, Paid, Closed; one active case per file; reassignment is audited | FI-06 | Client p.6 | Required document roles are configurable by purchase type |
| A2.09 | Matching scores reference numbers, supplier, dates, amounts, weight and goods; high confidence links automatically with a stored explanation | FI-07 | Client p.6 | A single weak signal never auto-links |
| A2.10 | Medium and low matches go to a review queue with ranked candidates and conflicts shown | FI-07 | Client p.6 | An ambiguous document stays unmatched until resolved |
| A2.11 | Accountants mark invoices paid manually with date, reference and user, and can note partial payments | FI-10 (manual part) | Plan: client p.7 starts at the bank file | Payment state is separate from completeness |
| A2.12 | A finance dashboard with monthly spend, paid on time, incomplete cases, review backlog, outstanding and overdue invoices and supplier history | FI-12 | Client p.8 | Totals reconcile with the UAT dataset |
| A2.13 | Invoices carry a type (default "standard") and a relation table, so credit notes and advances can be added later | EP-04 | Plan | Adding a type needs no migration of existing invoices |

### A3. HR core

| ID | Story | Plan ref | Source | Done when |
| --- | --- | --- | --- | --- |
| A3.01 | A person record stores every field in the Astex list: identity and travel, contact, employment and payroll, compliance identifiers | HR-01 | Client p.3 | All listed fields are stored, validated and reportable |
| A3.02 | People move through candidate, onboarding, active, leaving and former | HR-02 | Plan | Status drives dashboards and the requirement matrix |
| A3.03 | HR creates, sends, resends and revokes invitations; the link is a hashed, expiring, single-purpose token | HR-03 | Client p.3 | An expired or revoked link shows no personal data |
| A3.04 | A one-time email code is required before the form opens | HR-04 | Client p.3 (optional; we default it on) | A forwarded link cannot open the form |
| A3.05 | A mobile-first guided form with save-and-resume, conditional sections and privacy-notice version logging | HR-05 | Client p.3 | Each tested profile sees only its required sections |
| A3.06 | Server-side validation; final submission locks key fields until an audited reopen | HR-06 | Client p.3 | A locked field changes only with a recorded reason |
| A3.07 | HR reviews a submission for completeness and approves, requests completion or reopens | HR-03, HR-06 | Client p.3 | Each exception on the Astex list has its admin action |
| A3.08 | Possible duplicate people are proposed from email, name and document numbers; HR merges, links or keeps separate | HR-07 | Client p.3 | A merge keeps both histories |
| A3.09 | Document upload by type with OCR of the expiry fields Astex listed; every value needs human confirmation | HR-08 | Client p.4 | No extracted value becomes active unconfirmed |
| A3.10 | A configurable requirement matrix of fields and documents by nationality, permit route, job category and customer assignment | HR-09 | Client p.4 | A new requirement is added with no code change |
| A3.11 | Expiry reminders at configurable windows (default 90, 60, 30, 14, 7 days) with owner and severity; overdue items need a reason | HR-10 | Client p.4 | Reminders are never duplicated |
| A3.12 | Replacing a document keeps the previous one in history | HR-11 | Client p.4 | The full history is visible on the person |
| A3.13 | One Astex-approved template is filled from confirmed data into a versioned PDF; the signed scan is uploaded back | HR-12 | Client p.4 | The PDF matches the template and confirmed data |
| A3.14 | An HR dashboard (expiring, missing, unsigned, reviews, new submissions, incomplete profiles) and an assigned owner per person | HR-13, HR-14 | Client p.4, 8 | Counts match the lists |
| A3.15 | HR spreadsheets and document folders are imported through the A1.16 wizard | none | Client p.8 (goal only) | Trial loads reconcile |
| A3.16 | Employment data is stored as effective-dated records, with only current values shown in Part A | EP-05 | Plan | Module C20 can show history with no data conversion |

### Extension points built into Part A

These are the price of avoiding a redesign. Each is small, and none gives Astex a visible feature by itself.

| ID | What Part A builds | Why it matters | Used by |
| --- | --- | --- | --- |
| EP-01 | Module host: registry, menu slots, enable per entity, dependency checks | B and C modules appear without changing core code | all B and C |
| EP-02 | Workflow engine with a single-step default | Approvals, offboarding and change requests need real flows later | C01, C02, C21, C16 |
| EP-03 | Legal entity, cost centre and currency with a nullable HUF equivalent on every financial row | Adding coding, rates or a second entity later would otherwise migrate live data | C05, C06, C40 |
| EP-04 | Invoice type field and invoice relation table | Credit notes, storno and advances change how balances are computed | C03, C14 |
| EP-05 | Effective-dated tables for supplier bank accounts and employment records | History cannot be rebuilt once overwritten | C02, C20, C26 |
| EP-06 | One generic document-link table | New record types need no new file storage | C16, C22, C25, C30 |
| EP-07 | Event outbox and event catalog | Modules react to events instead of reaching into each other | all B and C |
| EP-08 | Adapter registry and credential vault | Banks, accounting software and providers are swapped by configuration | B1 to B7, C06, C10, C13, C26, C29, C31 |
| EP-09 | Permission registry that modules add to | Roles stay consistent as modules arrive | all B and C |
| EP-10 | Task-type registry | Every module's exceptions land in the one inbox | all B and C |
| EP-11 | Notification-template registry | Modules ship their own emails in both languages | C01, C09, C23, C29 |
| EP-12 | Settings with a per-module schema and feature flags | Modules are configured in admin screens, not in code | all B and C |

## 3. Part B: conditional modules

Each is described in the Astex document but cannot be fully designed until Astex supplies the item under "Client must supply". Module work is split in two for estimating: the **framework** (screens, rules, events, which are known now) and the **adapter** (the outside format or API, estimated as a range until the specification arrives).

{{B_OVERVIEW}}

{{B_CARDS}}

## 4. Part C: suggested additions

None of these is in the Astex document. Each follows the same contract as Part B and can be accepted or declined on its own. Several require another module; the dependency table in section 5 prevents invalid selections.

{{C_OVERVIEW}}

{{C_CARDS}}

## 5. Dependencies and packages

### Module dependencies

{{DEPS}}

### Proposed packages

These are starting points for the decision sheet in the proposal, not prices.

{{BUNDLES}}

## 6. What Astex must supply

Most delays on earlier projects came from missing inputs. This table is the client's homework list, grouped by module.

{{HOMEWORK}}

## 7. Module contract standard

Every B and C module is delivered as a plugin that follows this standard. It is deliberately independent of the technology stack, which is not yet decided.

### 7.1 Module manifest

Each module ships a manifest the module host reads:

```yaml
id: C01                      # unique, matches this backlog
name: Approval workflows
version: 1.0.0
requires: [A2]               # must be enabled first
optional: []                 # used if present
permissions:                 # added to the permission registry (EP-09)
  - finance.approvals.act
  - finance.approvals.configure
menu:                        # slots in the shell (EP-01)
  - slot: finance.approvals.inbox
    label: { en: Approval inbox, hu: Jóváhagyási postafiók }
    route: /finance/approvals
    permission: finance.approvals.act
settings: schema/settings.json     # JSON Schema; secrets are referenced by name, never stored here
events:
  consumes: [invoice.confirmed]
  produces: [invoice.approved, invoice.rejected, approval.escalated]
tasks: [approval.pending]          # task types added to the inbox (EP-10)
templates: [approval-request, approval-reminder]   # notification templates (EP-11)
adapter: null                      # or the adapter interface name (section 9)
health: /health                    # reports ok, degraded or failed
migrations: migrations/            # the module owns its tables
```

### 7.2 Rules every module follows

1. **Own its data.** A module creates its own tables, prefixed with its ID. It reads core data through published views and changes core data only through the declared extension points (EP-01 to EP-12).
2. **Talk through events.** A module never calls another module directly. It publishes and consumes events from the catalog in section 8.
3. **Enable, disable, never delete.** Enabling checks that required modules are on. Disabling is blocked while another enabled module requires it. A disabled module's data stays, read-only, and is still covered by retention rules.
4. **Everything audited and permissioned.** Each action is checked against a registered permission and written to the audit trail with the module ID as the source.
5. **Failures are visible.** A failed job creates a task with an owner. Retries are idempotent, and an adapter error carries a code and a `retryable` flag.
6. **Tested against samples.** A module is accepted only when it passes its own test samples (listed on each card) supplied by Astex or recorded from the outside system.
7. **Both languages.** Labels, emails and validation messages exist in English and Hungarian.

## 8. Event catalog

Every event uses one envelope:

```json
{ "id": "uuid", "type": "invoice.confirmed", "version": 1, "occurredAt": "ISO-8601",
  "entityId": "legal entity", "actor": "user or system", "correlationId": "uuid",
  "payload": { } }
```

| Event | Produced by | Payload essentials | Typical consumers |
| --- | --- | --- | --- |
| invoice.received | A2, B1 | fileId, source (upload, email), receivedAt | A2 OCR job |
| invoice.extracted | A2 | invoiceId, fields with confidence | C04 duplicate check |
| invoice.confirmed | A2 | invoiceId, supplierId, gross, currency | C01, C05, C06, C09, B4 |
| invoice.translated | A2 | invoiceId, language, textId | search index |
| invoice.approved | C01 | invoiceId, approvers | C07, B4 |
| invoice.coded | C05 | invoiceId, coding lines | C10 |
| invoice.paid | A2, C08 | invoiceId, amount, date, reference | A2 case state, C15 |
| case.ready | A2 | caseId, completeness | B3 |
| supplier.bank_changed | A2 | supplierId, old, new | C02 |
| payment.batch_created / _approved / _exported | C07, B4 | batchId, invoice ids, total | B4, B6, C08 |
| payment.confirmed | C08 | batchId or invoiceId, statementLineId | A2, C07 |
| nav.invoice_imported | B2 | navInvoiceId, matchedInvoiceId or null | C09 |
| ekaer.finalised | B3 | caseId, declarationRef, time | A2 case timeline |
| export.created | C10 | exportId, period, invoice ids | C11 |
| person.invited / .submitted / .approved / .left | A3, C21 | personId | C20, C24, C26, C29 |
| document.expiring / .expired / .replaced | A3 | personId, documentType, expiryDate, window | C23, C28, C29 |
| employment.changed | C20 | personId, effective date, fields | C26 |
| job.failed | A1 | jobId, class, owner | task inbox |

## 9. Adapter interfaces

Adapters are the only code that knows about an outside system. They are shown in TypeScript-style notation for readability; the signatures are the contract, not the language. Each is estimated separately once the specification for that system is supplied.

```ts
type Result<T> =
  | { ok: true; value: T }
  | { ok: false; error: { code: string; retryable: boolean; message: string } };

// A1, B7
interface OcrProvider {
  extract(file: FileRef, docType: DocType, opts?: { languages?: string[] }): Promise<Result<{
    fields: { name: string; value: string; confidence: number; page: number; box?: BBox }[];
    fullText: string; language?: string; raw: unknown }>>;
}
interface TranslationProvider {
  translate(text: string, from: string | "auto", to: "en"): Promise<Result<{ text: string; detectedFrom: string }>>;
}

// B1
interface InboundMailAdapter {
  parse(raw: RawMessage): Promise<Result<{ messageId: string; sender: string; subject: string; attachments: FileRef[] }>>;
}

// B2
interface NavInvoiceAdapter {
  queryInvoices(range: DateRange, page: number): Promise<Result<{ invoices: NavInvoice[]; nextPage?: number }>>;
  health(): Promise<Result<{ environment: "test" | "production" }>>;
}

// B3
interface EkaerAdapter {
  create(d: EkaerDeclaration): Promise<Result<{ ref: string }>>;
  modify(ref: string, patch: Partial<EkaerDeclaration>): Promise<Result<void>>;
  finalise(ref: string): Promise<Result<{ finalisedAt: string }>>;
  status(ref: string): Promise<Result<EkaerStatus>>;
}

// B4, B6
interface BankPaymentFormat {
  id: string; // e.g. "hu-domestic-huf", "sepa-pain001"
  validate(batch: PaymentBatch): Result<void>;
  generate(batch: PaymentBatch): Result<{ file: FileRef; checksum: string }>;
}
interface BankApiAdapter {
  submit(batch: PaymentBatch): Promise<Result<{ bankRef: string }>>;
  fetchStatements(account: string, since: string): Promise<Result<StatementLine[]>>;
  authStatus(): Promise<Result<{ validUntil: string }>>;
}

// B5, C08
interface BankNoticeParser { parse(email: ParsedEmail): Result<PaymentNotice | null>; }
interface StatementParser {
  id: string; // "camt053", "mt940", "csv-<bank>"
  parse(file: FileRef): Result<StatementLine[]>;
}

// C06
interface ExchangeRateSource { rate(currency: string, date: string): Promise<Result<{ rate: string; date: string }>>; }

// C10
interface AccountingExporter {
  id: string; // one per accounting package
  mapping(): MappingSchema;
  export(period: Period, entries: CodedInvoice[]): Promise<Result<{ file?: FileRef; externalRef?: string; rejected: { invoiceId: string; reason: string }[] }>>;
}

// C13
interface VatValidator { validate(country: string, number: string): Promise<Result<{ valid: boolean; name?: string; address?: string }>>; }

// C26
interface PayrollExporter { export(changes: PayrollChange[], period: Period): Promise<Result<{ file: FileRef }>>; }

// C29
interface MessagingProvider { send(to: string, templateId: string, vars: Record<string, string>, lang: string): Promise<Result<{ messageId: string }>>; }

// C31
interface SignatureProvider {
  send(doc: FileRef, signers: Signer[]): Promise<Result<{ envelopeId: string }>>;
  status(envelopeId: string): Promise<Result<SignatureStatus>>;
}
```

Amounts are decimal strings, never floating-point numbers. Dates are ISO 8601.

## 10. Parked: not planned unless Astex asks

{{PARKED}}

## 11. How this feeds the next tasks

- **Task 2 (estimate).** Each module in `data/modules.json` gets low, likely and high hours for framework and adapter, at 25 USD per hour and two developers. Part A epics are estimated story by story from the tables above.
- **Task 3 (screens).** The screen list and clickable mockup read the same module registry, so every screen is tagged A, B or C and can be hidden when its module is not in the chosen package.
