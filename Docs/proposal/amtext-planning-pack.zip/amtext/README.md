# Astex HR and Finance Platform: planning pack (task 1 and the screen part of task 3)

| File | What it is |
| --- | --- |
| `docs/01-backlog.md` | Backlog in three parts: A core, B conditional plugin modules, C suggested plugin modules. Includes extension points, module contract, event catalog, adapter interfaces, packages |
| `docs/02-user-journeys.md` | User journeys for every module |
| `docs/03-screen-list.md` | All 86 screens: purpose, key elements, roles, module |
| `mockup/index.html` | Clickable mockup. One file, opens in any browser, sample data only |
| `data/modules.json`, `data/screens.json` | Single source of truth for modules and screens |
| `data/module-catalog.csv` | One row per module with effort (low, likely, high) and adapter hours |
| `data/effort.json` | Hours per story and module, uncertainty classes, overheads, rate: the input of the estimate |
| `docs/04-estimate.xlsx` | Formula-driven estimate: change rate, overheads or package flags and everything recalculates |

## Rebuild

```
python3 tools/build_docs.py      # docs/01-backlog.md, docs/03-screen-list.md, data/module-catalog.csv
python3 tools/build_estimate.py  # docs/04-estimate.xlsx; fills effort columns in data/module-catalog.csv (run after build_docs.py)
python3 tools/build_mockup.py    # mockup/index.html
```

Edit `data/*.json`, `docs/src/01-backlog.template.md` or `mockup/src/*`, then rebuild. Do not edit the generated files by hand.

## Using the mockup

- **Package** selector (top bar): Core, Recommended, Extended, Full. Screens of modules outside the package are greyed with a lock. Opening one explains what it adds and lets you add it.
- **Signed in as** selector: the menu and screens change by role.
- Module catalog (Administration, Setup) lets you tick modules one by one. Dependencies follow automatically.
- Try: invoice register, open a "Needs review" row, fix the gross amount, confirm. Then switch to the finance manager and approve in the approval inbox. The worker's phone form is linked at the bottom of the menu.
